
from typing import Dict
import numpy as np
from pyltp import Postagger, Parser, Segmentor
import os

class MilitarySchema:
    def __init__(self):
        self.entity_type_2_id = {'O': 0, 'ZBGC':1, 'Contract':2, 'ZB_other':3, 'Media':4, 'GPE':5, 'sign':6,
                                 'hold-meeting':7, 'Org':8, 'VEH':9, 'Attack':10, 'GPS':11, 'Law':12, 'Time':13,
                                 'visit':14, 'Party':15, 'Person':16, 'ZB_ocean':17, 'ZB_land':18, 'Transaction':19,
                                 'Economic-Conflicts':20, 'WZ':21, 'BD':22, 'phone-call':23, 'ZB_gun':24, 'Meeting':25,
                                 'Act-against':26, 'ZB_air':27, 'attend-meeting':28, 'Location':29, 'Language-Conflicts':30,
                                 '$element$':31, 'Money':32, 'War-Cooperation':33, 'meet':34, 'Country':35, 'Deploy':36
                                 }
        self.id_2_entity_type = {
                                0: 'O', 1: 'ZBGC', 2:'Contract', 3:'ZB_other', 4:'Media', 5:'GPE', 6:'sign', 7:'hold-meeting', 8:'Org', 9:'VEH',
                                10:'Attack', 11:'GPS', 12:'Law', 13:'Time', 14:'visit', 15:'Party', 16:'Person',
                                    17:'ZB_ocean', 18:'ZB_land', 19:'Transaction', 20:'Economic-Conflicts', 21:'WZ',
                                    22:'BD', 23:'phone-call', 24:'ZB_gun', 25:'Meeting', 26:'Act-against', 27:'ZB_air',
                                    28:'attend-meeting', 29:'Location', 30:'Language-Conflicts', 31:'$element$',
                                    32:'Money', 33:'War-Cooperation', 34:'meet', 35:'Country', 36:'Deploy'
        }

        self.event_type_2_id = {'O': 0, 'Language-Conflicts':1, 'Attack':2, 'Transaction':3, 'Economic-Conflicts':4,
                                'War-Cooperation':5, 'meet':6, 'visit':7, 'phone-call':8, 'Act-against':9,
                                'attend-meeting':10, 'sign':11, 'hold-meeting':12, 'Deploy':13}
        self.id_2_event_type = {
                                0: 'O', 1: 'Language-Conflicts', 2:'Attack', 3:'Transaction', 4:'Economic-Conflicts', 5:'War-Cooperation',
                                6:'meet', 7:'visit', 8:'phone-call', 9:'Act-against', 10:'attend-meeting', 11:'sign',
            12:'hold-meeting', 13:'Deploy'
        }

        self.role_type_2_id = {'O': 0, 'Meeting-Arg':1, 'Org-Arg':2, '$element$-Arg':3, 'Party-Arg':4, 'BD-Arg':5,
                               'ZB_air-Arg':6, 'ZB_land-Arg':7, 'WZ-Arg':8, 'VEH-Arg':9, 'ZB_other-Arg':10,
                               'GPE-Arg':11, 'ZBGC-Arg':12, 'ZB_gun-Arg':13, 'Country-Arg':14, 'Person-Arg':15,
                               'Law-Arg':16, 'GPS-Arg':17, 'Contract-Arg':18, 'Media-Arg':19, 'ZB_ocean-Arg':20,
                               'Money-Arg':21, 'Location-Arg':22, 'Time-Arg':23}

        self.id_2_role_type = {0: 'O', 1:'Meeting-Arg', 2:'Org-Arg', 3:'$element$-Arg', 4:'Party-Arg', 5:'BD-Arg',
                               6:'ZB_air-Arg', 7:'ZB_land-Arg', 8:'WZ-Arg', 9:'VEH-Arg', 10:'ZB_other-Arg', 11:'GPE-Arg',
                               12:'ZBGC-Arg', 13:'ZB_gun-Arg', 14:'Country-Arg', 15:'Person-Arg', 16:'Law-Arg',
                               17:'GPS-Arg', 18:'Contract-Arg', 19:'Media-Arg', 20:'ZB_ocean-Arg', 21:'Money-Arg',
                               22:'Location-Arg', 23:'Time-Arg' }


        self.arc_type_id = {'O': 0, 'ATT': 1, 'ADV': 2, 'RAD': 3, 'WP': 4, 'SBV': 5, 'VOB': 6, 'HED': 7, 'COO': 8,
                            'CMP': 9,'POB': 10, 'LAD': 11, 'DBL': 12, 'FOB': 13, 'IOB': 14}





def init_pyltp(ltp_dir):
    postagger = Postagger()
    postagger.load(os.path.join(ltp_dir, 'pos.model'))
    parser = Parser()
    parser.load(os.path.join(ltp_dir, 'parser.model'))
    seg = Segmentor()
    seg.load(os.path.join(ltp_dir, 'cws.model'))
    return postagger, parser, seg





class InputExample:

    def __init__(self, text: str, text_ids: list, schema: MilitarySchema, text_tokenized: list,
                 candidate_arguments: list, candidate_trigger_idxs: list, gold_triggers: list, arces: list,
                 arc_type_2_id: dict, relations: dict, events: dict):
        
        self.text = text  
        self.text_len = len(text_ids) 
        
        self.text_ids = text_ids
        if self.text_len > 512:
            self.text_ids = self.text_ids[:512]
            self.text_len = 512
        self.text_tokenized = text_tokenized
        self.text_map_seg, self.seg_map_text = self.align_text_seg()

        self.arc_matrix = self.get_arc_matrix(arces, arc_type_2_id, candidate_arguments, gold_triggers)
        self.entity_schema_2_id = schema.entity_type_2_id
        self.schema = schema
        self.entity_id_2_id = self.entity_map_id(candidate_arguments)
        self.triggers = gold_triggers
        self.arguments = candidate_arguments
        self.relation = relations

        self.candidate_arguments, self.candidate_argument_range, self.candidate_argument_type = self.get_candidate_arguments(
            candidate_arguments) 
        self.candidate_triggers, self.candidate_trigger_ranges, self.trigger_label, self.triggers_arguments_label = self.get_candidate_triggers(
            candidate_trigger_idxs,
            gold_triggers, events,
            candidate_arguments)
        self.trigger_arc, self.trigger_related, self.trigger_max_num_arc = self.get_arc_related(self.candidate_triggers,
                                                                                                self.candidate_trigger_ranges)
        self.argument_arc, self.argument_related, self.argument_max_num_arc = self.get_arc_related(
            self.candidate_arguments, self.candidate_argument_range)

        self.argument_argument_label = self.get_argument_argument_label(relations)

    def entity_map_id(self, candidate_arguments):
        entity_id_2_id = {}
        for argument in candidate_arguments:
            if argument['entity_id'] not in entity_id_2_id:
                entity_id_2_id[argument['entity_id']] = len(entity_id_2_id)
        return entity_id_2_id

    def get_argument_argument_label(self, relations):
        arguments_relations = np.zeros((len(self.entity_id_2_id), len(self.entity_id_2_id)))
        for rel in relations.values():
            if rel['arg1']['end_pos'] > 512 or rel['arg2']['end_pos'] > 512:
                continue
            relation_id = self.schema.relation_type_2_id[rel['relation_type']]
            arg1_entity_id = self.entity_id_2_id[rel['arg1']['entity_id']]
            arg2_entity_id = self.entity_id_2_id[rel['arg2']['entity_id']]
            arguments_relations[arg1_entity_id:arg2_entity_id] = relation_id
        return arguments_relations

    def get_arc_related(self, candidate, candidate_range):
        candidate_arc = []
        max_num_arc = 0
        candidate_related = []

        for candidate_tensor, candidate_range in zip(candidate, candidate_range):
            if candidate_range[1] > 512:
                continue
            related_idx = np.nonzero(np.dot(candidate_tensor, self.arc_matrix))[0].tolist()
            arcs = []
            related = []
            for (start, end) in get_start_end(related_idx):
                segs_idx = set()
                for text_idx in range(start, end):
                    segs_idx.add(self.text_map_seg[text_idx])
                for seg_idx in segs_idx:
                    (text_b, text_e) = self.seg_map_text[seg_idx]
                    related_tensor = np.zeros(self.text_len)
                    related_tensor[text_b:text_e] = 1. / (text_e - text_b)
                    related.append(related_tensor)

                    arc_type = np.unique(self.arc_matrix[candidate_range[0]:candidate_range[1], text_b:text_e]).tolist()

                    arcs.append(max(arc_type))

            max_num_arc = max(max_num_arc, len(arcs))
            assert len(arcs) == len(related), 'xx'
            candidate_arc.append(arcs)
            candidate_related.append(related)

        return candidate_arc, candidate_related, max_num_arc

    def get_arc_matrix(self, arces, arc_type_2_id, candidate_arguments, gold_triggers):
        arc_matrix = np.zeros((self.text_len, self.text_len))

        for son_idx, arc in enumerate(arces):
            (father_idx, arc_type) = arc.split(':')
            if int(father_idx) == 0:
                continue
            row_start, row_end = self.seg_map_text[(int(father_idx) - 1)]
            col_start, col_end = self.seg_map_text[son_idx]
            arc_matrix[row_start:row_end, col_start:col_end] = arc_type_2_id[arc_type] * 2
            arc_matrix[col_start:col_end, row_start:row_end] = arc_type_2_id[arc_type] * 2 + 1
        for ent in (candidate_arguments + gold_triggers):
            start_pos, end_pos = int(ent['start_pos']), int(ent['end_pos'])
            arc_matrix[start_pos:end_pos, start_pos:end_pos] = 0.
        return arc_matrix

    def get_candidate_arguments(self, candidate_arguments):
        candidate_argument = []
        candidate_argument_type = []
        candidate_argument_range = []
        for ent in candidate_arguments:
            candidate_argument_type.append(self.entity_schema_2_id[ent['entity_type']])
            argument_tensor = np.zeros(self.text_len)
            argument_tensor[int(ent['start_pos']):int(ent['end_pos'])] = 1. / (
                    int(ent['end_pos']) - int(ent['start_pos']))
            candidate_argument_range.append((int(ent['start_pos']), int(ent['end_pos'])))
            candidate_argument.append(argument_tensor)
        return candidate_argument, candidate_argument_range, candidate_argument_type

    def get_candidate_triggers(self, candidate_trigger_idxs, gold_triggers, events, candidate_arguments):
        """
        :param gold_triggers:
        :return:
        """
        candidate_triggers = []
        gold_triggers_idx = []
        triggers_idx = []
        trigger_label = []
        triggers_arguments = []

        candidate_trigger_ranges = []
        for ent in gold_triggers:
            trigger_tensor = np.zeros(self.text_len)
            trigger_tensor[int(ent['start_pos']):int(ent['end_pos'])] = 1. / (
                    int(ent['end_pos']) - int(ent['start_pos']))
            candidate_triggers.append(trigger_tensor)
            candidate_trigger_ranges.append((int(ent['start_pos']), int(ent['end_pos'])))
            related_argument_tensor = np.zeros(len(self.entity_id_2_id))
            for event in events.values():
                if ent['entity_id'] == event['trigger']['entity_id']:
                    trigger_label.append(self.schema.event_type_2_id[ent['entity_type']])
                    for argument in event['arguments']:
                        if argument['argument']['end_pos'] > 512:
                            continue
                        role_id = self.schema.role_type_2_id[argument['role_type']]
                        entity_id = self.entity_id_2_id[argument['argument']['entity_id']]
                        related_argument_tensor[entity_id] = role_id

            triggers_arguments.append(related_argument_tensor)

        for idx in candidate_trigger_idxs:
            if self.seg_map_text[idx][1] > 512:
                continue
            if idx not in gold_triggers_idx:
                triggers_idx.append(idx)
                trigger_tensor = np.zeros(self.text_len)
                start, end = self.seg_map_text[idx]
                trigger_tensor[start:end] = 1. / (end - start)
                candidate_triggers.append(trigger_tensor)
                candidate_trigger_ranges.append((start, end))
                trigger_label.append(0)
                related_argument_tensor = np.zeros(len(self.entity_id_2_id))
                triggers_arguments.append(related_argument_tensor)
        assert len(trigger_label) == len(triggers_arguments), 'abc'
        return candidate_triggers, candidate_trigger_ranges, trigger_label, triggers_arguments

    def align_text_seg(self) -> (Dict, Dict):
        """
        align tokenized text to raw text
        :return:
            text_map_seg:{0:0,1:0,2:0,3:1,4:1,...} key = char id(in text), value = token id(in text_tokenized)
            seg_map_text:{0:(0,3),1:(3,5)}  text_map_seg  reverse map
        """
        point = 0
        text_map_seg = {}
        seg_map_text = {}
        for idx, token in enumerate(self.text_tokenized):
            token_len = len(token)
            seg_map_text[idx] = (point, point + token_len)
            for i in range(point, point + token_len):
                text_map_seg[i] = idx
            point += token_len
        return text_map_seg, seg_map_text


def get_start_end(arr: list):
    if not arr:
        return []
    if len(arr) == 1:
        return [(arr[0], arr[0])]
    ans = []
    left, right = 0, 1
    while right < len(arr):
        if arr[right] - 1 == arr[right - 1]:
            right += 1
        else:
            ans.append((arr[left], arr[right - 1]))
            left = right
            right += 1
    ans.append((arr[left], arr[right - 1]))
    return ans


def get_trigger_candidate_index(postaggers):
    """
    get trigger candidate index
    :return:
    """
    trigger_idxs = []
    for idx, postag in enumerate(postaggers):
        if postag in ['n', 'v']:
            trigger_idxs.append(idx)
    return trigger_idxs


def get_trigger_gold(events: Dict):
    """
   
    :param events:
    :return:
    """
    triggers_gold = []
    for key, ent in events.items():
        if int(ent['trigger']['end_pos']) > 510:
            continue
        triggers_gold.append(ent['trigger'])
    return triggers_gold


def get_candidate_argument(entities: Dict):
    """
    
    :param entities:
    :return:
    """
    ents = []
    for key, ent in entities.items():
        if int(ent['end_pos']) > 510:
            continue
        ent['entity_id'] = key
        ents.append(ent)
    return ents


def get_parse_arces(text_tokenized, postagger, parser):
    poses = ' '.join(postagger.postag(text_tokenized)).split()
    arcs = parser.parse(text_tokenized, poses)
    arces = ' '.join("%d:%s" % (arc.head, arc.relation) for arc in arcs).split()
    return arces


def get_trigger_text(trigger_pred, triggers_idx, texts):
    id_2_event_type = {
        0: 'O', 1: '交通肇事事件', 2: '抢劫事件', 3: '故意杀人事件', 4: '诈骗事件', 5: '危险驾驶事件', 6: '审判事件',
        7: '拘留事件', 8: '逮捕事件', 9: '保释事件', 10: '盗窃事件', 11: '故意伤害事件'
    }
    b, k, l = triggers_idx.shape
    pred = trigger_pred.cpu().detach().numpy()
    trigger_tensors = triggers_idx.cpu().detach().numpy()
    res = []
    for i in range(b):
        temp_res = []
        trigger_type_id = pred[i]
        for j in range(k):
            if trigger_type_id[j] > 0:
                trigger_type = id_2_event_type[trigger_type_id[j]]
                trigger_idx = trigger_tensors[i][j]
                text = texts[i]
                res_text = get_text(trigger_idx, text)
                temp_res.append((res_text, trigger_type))
    return res


# ----------------------------------------------------------------


def align_text_seg(text_tokenized) -> (Dict, Dict):
    """
    align tokenized text to raw text
    :return:
        text_map_seg:{0:0,1:0,2:0,3:1,4:1,...} key = char id(in text), value = token id(in text_tokenized)
        seg_map_text:{0:(0,3),1:(3,5)}  text_map_seg  reverse map
    """
    point = 0
    text_map_seg = {}
    seg_map_text = {}
    for idx, token in enumerate(text_tokenized):
        token_len = len(token)
        seg_map_text[idx] = (point, point + token_len)
        for i in range(point, point + token_len):
            text_map_seg[i] = idx
        point += token_len
    return text_map_seg, seg_map_text


def get_arc_matrix(text_len, seg_map_text, arces, arc_type_2_id):
    arc_matrix = np.zeros((text_len, text_len))

    for son_idx, arc in enumerate(arces):
        (father_idx, arc_type) = arc.split(':')
        if int(father_idx) == 0:
            continue
        row_start, row_end = seg_map_text[(int(father_idx) - 1)]
        col_start, col_end = seg_map_text[son_idx]
        arc_matrix[row_start:row_end, col_start:col_end] = arc_type_2_id[arc_type] * 2
        arc_matrix[col_start:col_end, row_start:row_end] = arc_type_2_id[arc_type] * 2 + 1
    # for ent in (candidate_arguments + gold_triggers):
    #     start_pos, end_pos = int(ent['start_pos']), int(ent['end_pos'])
    #     arc_matrix[start_pos:end_pos, start_pos:end_pos] = 0.
    return arc_matrix


def entity_map_id(entities):
    """
    :return:
    """
    entity_id_2_id = {}
    for key, ent in entities.items():
        if key not in entity_id_2_id and int(ent['end_pos']) <= 510:
            entity_id_2_id[key] = len(entity_id_2_id)
    return entity_id_2_id


def get_candidate_arguments(text_len, entity_schema_2_id, candidate_arguments):
    candidate_argument = []
    candidate_argument_type = []
    candidate_argument_range = []
    for ent in candidate_arguments:
        candidate_argument_type.append(entity_schema_2_id[ent['entity_type']])
        argument_tensor = np.zeros(text_len)
        argument_tensor[int(ent['start_pos']):int(ent['end_pos'])] = 1. / (
                int(ent['end_pos']) - int(ent['start_pos']))
        candidate_argument_range.append((int(ent['start_pos']), int(ent['end_pos'])))
        candidate_argument.append(argument_tensor)
    return candidate_argument, candidate_argument_range, candidate_argument_type


def get_candidate_triggers(text_len, candidate_trigger_idxs, seg_map_text, entity_id_2_id):
    """
    :param gold_triggers:
    :return:
    """
    candidate_triggers = []
    triggers_idx = []
    trigger_label = []
    triggers_arguments = []
    candidate_trigger_ranges = []

    for idx in candidate_trigger_idxs:
        if seg_map_text[idx][1] > 510:
            continue

        triggers_idx.append(idx)
        trigger_tensor = np.zeros(text_len)
        start, end = seg_map_text[idx]
        trigger_tensor[start:end] = 1. / (end - start)
        candidate_triggers.append(trigger_tensor)
        candidate_trigger_ranges.append((start, end))
        trigger_label.append(0)
        related_argument_tensor = np.zeros(len(entity_id_2_id))
        triggers_arguments.append(related_argument_tensor)
    assert len(trigger_label) == len(triggers_arguments), 'abc'
    return candidate_triggers, candidate_trigger_ranges, trigger_label, triggers_arguments


def get_candidate_triggers(text_len, entity_id_2_id, schema, seg_map_text, candidate_trigger_idxs, gold_triggers,
                           events):
    """
    
    """
    candidate_triggers = []
    gold_triggers_idx = []
    triggers_idx = []
    trigger_label = []
    triggers_arguments_mat = []
    candidate_trigger_ranges = []

    for ent in gold_triggers:
        trigger_tensor = np.zeros(text_len)
        trigger_tensor[int(ent['start_pos']):int(ent['end_pos'])] = 1. / (
                int(ent['end_pos']) - int(ent['start_pos']))
        candidate_triggers.append(trigger_tensor)
        candidate_trigger_ranges.append((int(ent['start_pos']), int(ent['end_pos'])))

        related_argument_tensor = np.zeros(len(entity_id_2_id))
        for event in events.values():
            if ent['entity_id'] == event['trigger']['entity_id']:
                for argument in event['arguments']:
                    if argument['argument']['end_pos'] > 510:
                        continue
                    role_id = schema.role_type_2_id[argument['role_type']]
                    entity_id = entity_id_2_id[argument['argument']['entity_id']]
                    related_argument_tensor[entity_id] = role_id
        triggers_arguments_mat.append(related_argument_tensor)
        trigger_label.append(schema.event_type_2_id[ent['entity_type']])

    for idx in candidate_trigger_idxs:
        if seg_map_text[idx][1] > 512:
            continue
        if idx not in gold_triggers_idx:
            triggers_idx.append(idx)
            trigger_tensor = np.zeros(text_len)
            start, end = seg_map_text[idx]
            trigger_tensor[start:end] = 1. / (end - start)
            candidate_triggers.append(trigger_tensor)
            candidate_trigger_ranges.append((start, end))
            trigger_label.append(0)
            related_argument_tensor = np.zeros(len(entity_id_2_id))
            triggers_arguments_mat.append(related_argument_tensor)
    assert len(trigger_label) == len(triggers_arguments_mat), 'the number of trigger is not right'
    triggers_arguments_mat = np.asarray(triggers_arguments_mat)
    return candidate_triggers, candidate_trigger_ranges, trigger_label, triggers_arguments_mat


def get_arc_related(text_len, text_map_seg, seg_map_text, candidate, candidate_range, arc_matrix):
    """

    :param text_len:
    :param text_map_seg:
    :param seg_map_text:
    :param candidate:
    :param candidate_range:
    :param arc_matrix:
    :return:
    """
    candidate_arc = []
    max_num_arc = 0
    candidate_related = []

    for candidate_tensor, candidate_range in zip(candidate, candidate_range):
        if candidate_range[1] > 510:
            continue
        related_idx = np.nonzero(np.dot(candidate_tensor, arc_matrix))[0].tolist()
        arcs = []
        related = []
        for (start, end) in get_start_end(related_idx):
            segs_idx = set() 
            for text_idx in range(start, end):
                segs_idx.add(text_map_seg[text_idx])
            for seg_idx in segs_idx:  
                (text_b, text_e) = seg_map_text[seg_idx]
                related_tensor = np.zeros(text_len)
                related_tensor[text_b:text_e] = 1. / (text_e - text_b)
                related.append(related_tensor)

                
                arc_type = np.unique(arc_matrix[candidate_range[0]:candidate_range[1], text_b:text_e]).tolist()
                arcs.append(max(arc_type))

        max_num_arc = max(max_num_arc, len(arcs))
        assert len(arcs) == len(related), 'arc nums is not equal to related entity num'
        candidate_arc.append(arcs)
        candidate_related.append(related)

    return candidate_arc, candidate_related, max_num_arc


def get_argument_argument_label(relations, entity_id_2_id, schema):
    """
   
    :param relations:
    :param schema:
    :return:
    """
    arguments_relations = np.zeros((len(entity_id_2_id), len(entity_id_2_id)))
    for rel in relations.values():
        if rel['arg1']['end_pos'] > 510 or rel['arg2']['end_pos'] > 510:
            continue
        relation_id = schema.relation_type_2_id[rel['relation_type']]
        arg1_entity_id = entity_id_2_id[rel['arg1']['entity_id']]
        arg2_entity_id = entity_id_2_id[rel['arg2']['entity_id']]
        arguments_relations[arg1_entity_id:arg2_entity_id] = relation_id
    return arguments_relations

