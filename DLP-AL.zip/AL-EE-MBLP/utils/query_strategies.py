
import torch.nn.functional as F
import torch
import numpy as np
import random
from datetime import datetime
from sklearn.cluster import KMeans

def margin_sampling(top_n, logists, embeddings, idxs_unlabeled):
    preds = F.softmax(logists, dim=-1)
    preds_sorted, idxs = preds.sort(descending=True)  
    U = preds_sorted[:, 0] - preds_sorted[:, 1]  
    residule_sorted, idx_sorted = U.sort()  
    return idxs_unlabeled[idx_sorted[:top_n]]


def random_sampling(top_n,logists,embeddings,idxs_unlabeled):
    """
    """
    idxs = [*range(len(idxs_unlabeled))]
    random.shuffle(idxs)
    idx = torch.IntTensor(np.array(idxs))
    return idxs_unlabeled[idx[:top_n]]

def loss_sampling(top_n,logists,embeddings,idxs_unlabeled):
    pred_losses = logists[2]
    pred_losses = torch.cat(pred_losses,dim=0).cpu().detach()
    preds_sorted, idx_sorted = pred_losses.sort(descending=True)  
    return idxs_unlabeled[idx_sorted[:top_n]]

def diversity_sampling(top_n,logists,embeddings,idxs_unlabeled):
    query_embedding = torch.cat(embeddings[1],dim=0).cpu().detach().numpy()
    cluster_learner = KMeans(n_clusters=top_n)
    cluster_learner.fit(query_embedding)

    cluster_idxs = cluster_learner.predict(query_embedding)
    centers = cluster_learner.cluster_centers_[cluster_idxs]
    dis = (query_embedding - centers) ** 2
    dis = dis.sum(axis=1)
    selected_idx = np.array(
        [ np.arange(query_embedding.shape[0])[cluster_idxs == i][dis[cluster_idxs == i].argmin()] for i in range(top_n)])
    return idxs_unlabeled[selected_idx]



def uncertainty_sampling(top_n, logists,embeddings, idxs_unlabeled):
    trigger_prob = logists[0]
    ta_prob = logists[1]

    preds = torch.tensor(trigger_prob) + torch.tensor(ta_prob)

    preds_sorted, idx_sorted = preds.sort(descending=True)  
    return idxs_unlabeled[idx_sorted[:top_n]]



def multilabel_margin_sampling(top_n, logists, embeddings, idxs_unlabeled):
    """
    """
    preds = F.sigmoid(logists)
    uncertainty = torch.sum(torch.abs(preds - torch.ones_like(preds) * 0.5), dim=-1)
    uncertainty_sorted, idx_sorted = uncertainty.sort()  
    return idxs_unlabeled[idx_sorted[:top_n]]


def LossPredLoss(input, target, margin=1.0, reduction='mean'):
    assert len(input) % 2 == 0, 'the batch size is not even.'
    assert input.shape == input.flip(0).shape

    input = (input - input.flip(0))[
            :len(input) // 2]  
    target = (target - target.flip(0))[:len(target) // 2]
    target = target.detach()

    one = 2 * torch.sign(torch.clamp(target, min=0)) - 1 

    if reduction == 'mean':
        loss = torch.sum(torch.clamp(margin - one * input, min=0))
        loss = loss / input.size(0)  
    elif reduction == 'none':
        loss = torch.clamp(margin - one * input, min=0)
    else:
        NotImplementedError()

    return loss