

from itertools import repeat
import pandas as pd
from model.metric import batch_f1, batch_precision, batch_recall, idification_precision, idification_recall, \
    idification_f1, categorical_accuracy


def inf_loop(data_loader):
    ''' wrapper function for endless data loader. '''
    for loader in repeat(data_loader):
        yield from loader


class MetricTracker:
    def __init__(self, *keys, writer=None):
        self.writer = writer
        self._data = pd.DataFrame(index=keys, columns=['total', 'counts', 'average'])
        self.reset()

    def reset(self):
        for col in self._data.columns:
            self._data[col].values[:] = 0

    def update(self, key, value, n=1):
        if self.writer is not None:
            self.writer.add_scalar(key, value)
        self._data.total[key] += value * n
        self._data.counts[key] += n
        self._data.average[key] = self._data.total[key] / self._data.counts[key]

    def avg(self, key):
        return self._data.average[key]

    def result(self):
        return dict(self._data.average)


def updata_metrics_log(metrics,trigger_pred, trigger_labels,ta_pred, trigger_argument_labels):
    # p r f
    trigger_f = batch_f1(trigger_pred, trigger_labels)

    metrics.update('trigger_f', trigger_f)

    ta_f = batch_f1(ta_pred, trigger_argument_labels)
    metrics.update('ta_f', ta_f)
