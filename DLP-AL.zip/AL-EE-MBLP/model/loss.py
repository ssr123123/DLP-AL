
import torch.nn.functional as F
from torch.nn import CrossEntropyLoss, BCEWithLogitsLoss
import torch
import numpy as np

def nll_loss(output, target):
    return F.nll_loss(output, target)


def trigger_crossentropy_loss(output, target,weight=None,reduction='mean'):
    output = output.transpose(1, 2)
    return F.cross_entropy(output, target,weight=weight,reduction=reduction)


def argument_crossentropy_loss(output, target,weight=None,reduction='mean'):
    B,M1,M2,N = output.size()
    output = output.reshape(B,M1*M2,N)
    output = output.transpose(2,1)
    output = output.reshape(B, N, M1 , M2)
    return F.cross_entropy(output, target,weight=weight,reduction=reduction)


def binary_crossentropy_loss(output, target):
    return F.binary_cross_entropy_with_logits(output, target)

def multi_label_crossentropy_loss(output, target,weight_):
    output = output.transpose(1, 2)
    weight_ = torch.from_numpy(np.array(weight_)).cuda().float()
    return F.cross_entropy(output, target, weight=weight_)