
import torch.nn as nn
import torch.nn.functional as F
import torch
from base import BaseModel
from operator import itemgetter
from transformers import BertModel, XLNetModel,AutoModel
from utils.model_utils import prepare_pack_padded_sequence, matrix_mul, element_wise_mul
# from .torch_crf_r import CRF as CRF_R
# from .torch_crf import CRF
import math
import numpy as np


class Pedal_attention(BaseModel):
    def __init__(self,
                 in_features,
                 head_num,
                 bias=True,
                 activation=F.relu):
        """Multi-head attention.
        :param in_features: Size of each input sample.
        :param head_num: Number of heads.
        :param bias: Whether to use the bias term.
        :param activation: The activation after each linear transformation.
        """
        super(Pedal_attention, self).__init__()
        self.in_features = in_features
        self.head_num = head_num
        self.bias = bias
        self.activation = activation

        self.multi_head = MultiHeadAttention(
            in_features=self.in_features,
            head_num=self.head_num,
            bias=self.bias,
            activation=self.activation
        )

    def forward(self, tail_words, head_words, value, mask=None, out_weight=False):
        # K B L D
        relation = self.multi_head(tail_words, head_words, value)

        return relation


class dJHEE(BaseModel):

    def __init__(self, bert_path, bert_train, dropout, hidden_dim, role_num, event_num, arc_type_num, entity_type_num):
        super(dJHEE, self).__init__()
        self.bert = BertModel.from_pretrained(bert_path)
       
        for name, param in self.bert.named_parameters():
            param.requires_grad = False
        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        self.trigger_classification_W = nn.Parameter(
            torch.Tensor(self.event_num, 768 + self.hidden_dim * 2).uniform_(-0.1, 0.1))
        self.trigger_classification_b = nn.Parameter(torch.Tensor(self.event_num).uniform_(-0.1, 0.1))

        self.ta_classification = nn.Linear(768 * 2 + 256 * 3 + 100, role_num)
        self.aa_classification = nn.Linear(768 * 2 + 256 * 2 + 100 * 2, role_num)

        self.arc_embedding = nn.Embedding(arc_type_num, 100) 
        self.argument_type_embedding = nn.Embedding(entity_type_num, 100)  

        self.trans_arc_words = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words_a = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arg_event = nn.Linear(768, self.hidden_dim)
        self.trans_arg_event_value = nn.Linear(768, self.hidden_dim)

        self.pedal_attention = Pedal_attention(768, 8)

        
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.dropout = nn.Dropout(dropout)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        tokens_embedding = self.bert(bert_token_ids, attention_mask=bert_masks)[0]

        # embedding of candidate

        trigger_arc_embed = self.arc_embedding(trigger_arc).transpose(1, 0)
        argument_arc_embed = self.arc_embedding(argument_arc).transpose(1, 0)

        # K,B,M,D
        trigger_related_embed = trigger_related.transpose(1, 0).matmul(tokens_embedding)
        trigger_arc_value = self.trans_arc_words(torch.cat([trigger_related_embed, trigger_arc_embed], dim=-1))
        # B,K,D
        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)
        # B,KK,DD
        argument_type_embed = self.argument_type_embedding(argument_type)
        argument_related_embed = argument_related.transpose(1, 0).matmul(tokens_embedding)
        argument_arc_value = self.trans_arc_words_a(torch.cat([argument_related_embed, argument_arc_embed], dim=-1))

        # trigger classify
        event_weight = self.HE(self.trans_arg_event(argument_embed))
        # B,C,M

        event_feature = event_weight.matmul(self.trans_arg_event_value(argument_embed))
        Be, Ce, De = event_feature.size()

        # B,K,D
        relation = self.pedal_attention(argument_embed, trigger_related_embed, trigger_arc_value).transpose(1, 0)
        B, K, M, D = relation.size()
        trigger_relation = F.max_pool2d(relation, kernel_size=(M, 1)).reshape(B, K, D)

        trigger_feature = torch.cat([trigger_relation, trigger_embed], dim=-1)
        Bt, Kt, Dt = trigger_feature.size()

        event_feature_t = event_feature.unsqueeze(1).repeat(1, Kt, 1, 1).reshape(Be, Kt, Ce, De)
        trigger_feature = trigger_feature.unsqueeze(2).repeat(1, 1, Ce, 1).reshape(Bt, Kt, Ce, Dt)

        hidden_trigger = torch.cat([event_feature_t, trigger_feature], dim=-1)

        # B,K,C
        # trigger_pred = F.softmax(torch.sum(hidden_trigger * self.trigger_classification_W, -1) + self.trigger_classification_b,dim=-1)
        trigger_pred = torch.sum(hidden_trigger * self.trigger_classification_W, -1) + self.trigger_classification_b
        trigger_pred_softmax = F.softmax(trigger_pred, dim=-1)

        # argument classify
        Ba, M, Da = argument_embed.size()
        event_feature_a = torch.bmm(trigger_pred_softmax, event_feature)
        event_feature_a = event_feature_a.unsqueeze(2).repeat(1, 1, M, 1)  # B,K,M,D
        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)
        argument_type_embed_a = argument_type_embed.unsqueeze(1).repeat(1, K, 1, 1)

        relation_aa = self.pedal_attention(argument_embed, argument_related_embed, argument_arc_value).transpose(1, 0)
        # B, M, M, D = relation.size()
        argument_relation = F.max_pool2d(relation_aa, kernel_size=(M, 1)).reshape(B, M, D).unsqueeze(
            1).repeat(1, K, 1, 1)
        # t-a-r
        ta_hidden = torch.cat([event_feature_a, trigger_feature_a, argument_feature_a, argument_relation, relation,
                               argument_type_embed_a], dim=-1)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r
        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_type_embed_aa1 = argument_type_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_type_embed_aa2 = argument_type_embed.unsqueeze(1).repeat(1, M, 1, 1)
        # argument_relation_aa = F.max_pool2d(relation.transpose(3, 2), kernel_size=(M,1)).reshape(B, M, D).unsqueeze(
        #     1).repeat(1, M, 1, 1)
        argument_relation_aa = F.max_pool2d(relation_aa, kernel_size=(M, 1)).reshape(B, M, D).unsqueeze(
            1).repeat(1, M, 1, 1)

        aa_hidden = torch.cat(
            [argument_type_embed_aa1, argument_feature_aa1, argument_feature_aa2, argument_relation_aa, relation_aa,
             argument_type_embed_aa2], dim=-1)
        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred


class HE_feature(BaseModel):

    def __init__(self, hidden_dim):
        super(HE_feature, self).__init__()
        self.hidden_dim = hidden_dim

        self.CRIME = nn.Linear(hidden_dim, 1, bias=False)
        self.LITIGATION = nn.Linear(hidden_dim, 1, bias=False)
        self.PUBLIC = nn.Linear(hidden_dim, 1, bias=False)
        self.PROPERTY = nn.Linear(hidden_dim, 1, bias=False)
        self.PERSONAL = nn.Linear(hidden_dim, 1, bias=False)
        self.DRIVING = nn.Linear(hidden_dim, 1, bias=False)
        self.TRAFFIC = nn.Linear(hidden_dim, 1, bias=False)
        self.LARCENY = nn.Linear(hidden_dim, 1, bias=False)
        self.FRAUD = nn.Linear(hidden_dim, 1, bias=False)
        self.ROBBERY = nn.Linear(hidden_dim, 1, bias=False)
        self.INJURY = nn.Linear(hidden_dim, 1, bias=False)
        self.KILL = nn.Linear(hidden_dim, 1, bias=False)
        self.ARREST = nn.Linear(hidden_dim, 1, bias=False)
        self.DETENTION = nn.Linear(hidden_dim, 1, bias=False)
        self.BAIL = nn.Linear(hidden_dim, 1, bias=False)
        self.TRIAL = nn.Linear(hidden_dim, 1, bias=False)
        self.OTHER = nn.Linear(hidden_dim, 1, bias=False)

    def forward(self, arguments):
        stock = F.softmax(self.CRIME(arguments).transpose(2, 1), dim=-1)
        sub = F.softmax(self.LITIGATION(arguments).transpose(2, 1), dim=-1)
        pledge = F.softmax(self.PUBLIC(arguments).transpose(2, 1), dim=-1)
        prosecute = F.softmax(self.PROPERTY(arguments).transpose(2, 1), dim=-1)
        invest = F.softmax(self.PERSONAL(arguments).transpose(2, 1), dim=-1)
        meet = F.softmax(self.DRIVING(arguments).transpose(2, 1), dim=-1)
        visit = F.softmax(self.TRAFFIC(arguments).transpose(2, 1), dim=-1)
        phone = F.softmax(self.LARCENY(arguments).transpose(2, 1), dim=-1)
        Act = F.softmax(self.FRAUD(arguments).transpose(2, 1), dim=-1)
        attend = F.softmax(self.ROBBERY(arguments).transpose(2, 1), dim=-1)
        sign = F.softmax(self.INJURY(arguments).transpose(2, 1), dim=-1)
        hold = F.softmax(self.KILL(arguments).transpose(2, 1), dim=-1)
        Deploy = F.softmax(self.ARREST(arguments).transpose(2, 1), dim=-1)
        other_weight = F.softmax(self.OTHER(arguments).transpose(2, 1), dim=-1)
        # DETENTION_weight = F.softmax(self.DETENTION(arguments).transpose(2, 1), dim=-1)
        # BAIL_weight = F.softmax(self.BAIL(arguments).transpose(2, 1), dim=-1)
        # TRIAL_weight = F.softmax(self.TRIAL(arguments).transpose(2, 1), dim=-1)
        # OTHER_weight = F.softmax(self.OTHER(arguments).transpose(2, 1), dim=-1)

        # # CRIME
        # PUBLIC_weight = (CRIME_weight + PUBLIC_weight) / 2
        # DRIVING_weight = (PUBLIC_weight + DRIVING_weight) / 2
        # TRAFFIC_weight = (PUBLIC_weight + TRAFFIC_weight) / 2
        #
        # PROPERTY_weight = (CRIME_weight + PROPERTY_weight) / 2
        # LARCENY_weight = (PROPERTY_weight + LARCENY_weight) / 2
        # FRAUD_weight = (PROPERTY_weight + FRAUD_weight) / 2
        # ROBBERY_weight = (PROPERTY_weight + ROBBERY_weight) / 2
        #
        # PERSONAL_weight = (CRIME_weight + PERSONAL_weight) / 2
        # INJURY_weight = (PERSONAL_weight + INJURY_weight) / 2
        # KILL_weight = (PERSONAL_weight + KILL_weight) / 2
        #
        # # LITIGATION
        # ARREST_weight = (ARREST_weight + LITIGATION_weight) / 2
        # DETENTION_weight = (DETENTION_weight + LITIGATION_weight) / 2
        # BAIL_weight = (BAIL_weight + LITIGATION_weight) / 2
        # TRIAL_weight = (TRIAL_weight + LITIGATION_weight) / 2

        event_weight = torch.cat([
            stock,
            sub,
            pledge,
            prosecute,
            invest,
            other_weight
        ], dim=1
        )
        # event_weight = {
        #     'CRIME_weight': CRIME_weight,
        #     'LITIGATION_weight': LITIGATION_weight,
        #     'PUBLIC_weight': PUBLIC_weight,
        #     'PROPERTY_weight': PROPERTY_weight,
        #     'PERSONAL_weight': PERSONAL_weight,
        #     'DRIVING_weight': DRIVING_weight,
        #     'TRAFFIC_weight': TRAFFIC_weight,
        #     'LARCENY_weight': LARCENY_weight,
        #     'FRAUD_weight': FRAUD_weight,
        #     'ROBBERY_weight': ROBBERY_weight,
        #     'INJURY_weight': INJURY_weight,
        #     'KILL_weight': KILL_weight,
        #     'ARREST_weight': ARREST_weight,
        #     'DETENTION_weight': DETENTION_weight,
        #     'BAIL_weight': BAIL_weight,
        #     'TRIAL_weight': TRIAL_weight
        # }
        return event_weight


class ScaledDotProductAttention(nn.Module):

    def forward(self, query, key, value, mask=None, out_weight=False):
        dk = query.size()[-1]
        # batch_size * self.head_num, seq_len1, sub_dim | k, batch_size * self.head_num, seq_len2, sub_dim
        scores = query.matmul(key.transpose(-2, -1)) / math.sqrt(dk)
        # batch_size * self.head_num, seq_len, seq_len
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        attention = F.softmax(scores, dim=-1)
        if out_weight:
            return attention, attention.matmul(value)
        # K, batch_size * self.head_num, seq_len, sub_dim
        return attention.matmul(value)


class MultiHeadAttention(nn.Module):

    def __init__(self,
                 in_features,
                 head_num,
                 bias=True,
                 activation=F.relu):
        """Multi-head attention.
        :param in_features: Size of each input sample.
        :param head_num: Number of heads.
        :param bias: Whether to use the bias term.
        :param activation: The activation after each linear transformation.
        """
        super(MultiHeadAttention, self).__init__()
        if in_features % head_num != 0:
            raise ValueError('`in_features`({}) should be divisible by `head_num`({})'.format(in_features, head_num))
        self.in_features = in_features
        self.head_num = head_num
        self.activation = activation
        self.bias = bias
        self.linear_q = nn.Linear(in_features, in_features, bias)
        self.linear_k = nn.Linear(in_features, in_features, bias)
        self.linear_v = nn.Linear(256, 256, bias)
        self.linear_o = nn.Linear(256, 256, bias)

    def forward(self, q, k, v, mask=None):
        q, k, v = self.linear_q(q), self.linear_k(k), self.linear_v(v)
        if self.activation is not None:
            q = self.activation(q)
            k = self.activation(k)
            v = self.activation(v)

        # q = self._reshape_to_batches(q)
        # k = self._reshape_to_batches_kv(k)
        # v = self._reshape_to_batches_kv(v)
        if mask is not None:
            mask = mask.repeat(self.head_num, 1, 1)
        y = ScaledDotProductAttention()(q, k, v, mask)
        # batch_size * self.head_num, seq_len, sub_dim
        # y = self._reshape_from_batches(y)

        y = self.linear_o(y)
        if self.activation is not None:
            y = self.activation(y)
        return y

    @staticmethod
    def gen_history_mask(x):
        """Generate the mask that only uses history data.
        :param x: Input tensor.
        :return: The mask.
        """
        batch_size, seq_len, _ = x.size()
        return torch.tril(torch.ones(seq_len, seq_len)).view(1, seq_len, seq_len).repeat(batch_size, 1, 1)

    def _reshape_to_batches_kv(self, x):
        K, batch_size, seq_len, in_feature = x.size()
        sub_dim = in_feature // self.head_num
        return x.reshape(K, batch_size, seq_len, self.head_num, sub_dim) \
            .permute(0, 1, 3, 2, 4) \
            .reshape(K, batch_size * self.head_num, seq_len, sub_dim)

    def _reshape_to_batches(self, x):
        batch_size, seq_len, in_feature = x.size()
        sub_dim = in_feature // self.head_num
        return x.reshape(batch_size, seq_len, self.head_num, sub_dim) \
            .permute(0, 2, 1, 3) \
            .reshape(batch_size * self.head_num, seq_len, sub_dim)

    def _reshape_from_batches(self, x):
        K, batch_size, seq_len, in_feature = x.size()
        # K, batch_size * self.head_num, seq_len, sub_dim
        batch_size //= self.head_num
        out_dim = in_feature * self.head_num
        return x.reshape(K, batch_size, self.head_num, seq_len, in_feature) \
            .permute(0, 1, 3, 2, 4) \
            .reshape(K, batch_size, seq_len, out_dim)

    def extra_repr(self):
        return 'in_features={}, head_num={}, bias={}, activation={}'.format(
            self.in_features, self.head_num, self.bias, self.activation,
        )


class dJHEE0(BaseModel):

    def __init__(self, bert_path, bert_train, dropout, hidden_dim, role_num, event_num, arc_type_num, entity_type_num):
        super(dJHEE0, self).__init__()
        self.bert = BertModel.from_pretrained(bert_path)
        
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        self.trigger_classification = nn.Linear(768, event_num)

        self.ta_classification = nn.Linear(768 * 2, role_num)
        self.aa_classification = nn.Linear(768 * 2, role_num)
        self.dropout = nn.Dropout(dropout)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        tokens_embedding = self.bert(bert_token_ids, attention_mask=bert_masks)[0]

        # embedding of candidate

        # K,B,M,D

        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)
        # B,KK,DD

        hidden_trigger = trigger_embed

        # B,K,C
        trigger_pred = self.trigger_classification(hidden_trigger)

        B, K, C = trigger_pred.size()

        # argument classify
        Ba, M, Da = argument_embed.size()

        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([trigger_feature_a, argument_feature_a], dim=-1)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r
        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)

        aa_hidden = torch.cat([argument_feature_aa1, argument_feature_aa2], dim=-1)
        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred


class dJHEE_HE(BaseModel):

    def __init__(self, bert_path, bert_train, dropout, hidden_dim, role_num, event_num, arc_type_num, entity_type_num):
        super(dJHEE_HE, self).__init__()
        self.bert = BertModel.from_pretrained(bert_path)
      
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        self.trigger_classification_W = nn.Parameter(
            torch.Tensor(self.event_num, 768 + self.hidden_dim).uniform_(-0.1, 0.1))
        self.trigger_classification_b = nn.Parameter(torch.Tensor(self.event_num).uniform_(-0.1, 0.1))

        self.ta_classification = nn.Linear(768 * 2 + self.hidden_dim, role_num)
        self.aa_classification = nn.Linear(768 * 2, role_num)

        self.trans_arg_event = nn.Linear(768, self.hidden_dim)
        self.trans_arg_event_value = nn.Linear(768, self.hidden_dim)

        
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.dropout = nn.Dropout(dropout)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        tokens_embedding = self.bert(bert_token_ids, attention_mask=bert_masks)[0]

        # embedding of candidate

        # K,B,M,D

        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        Bt, K, Dt = trigger_embed.size()

        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)
        # B,KK,DD

        event_weight = self.HE(self.trans_arg_event(argument_embed))
        event_feature = event_weight.matmul(self.trans_arg_event_value(argument_embed))
        Be, Ce, De = event_feature.size()

        event_feature_t = event_feature.unsqueeze(1).repeat(1, K, 1, 1).reshape(Be, K, Ce, De)
        trigger_embed_t = trigger_embed.unsqueeze(2).repeat(1, 1, Ce, 1).reshape(Bt, K, Ce, Dt)

        hidden_trigger = torch.cat([trigger_embed_t, event_feature_t], dim=-1)

        trigger_pred = torch.sum(hidden_trigger * self.trigger_classification_W, -1) + self.trigger_classification_b
        trigger_pred_softmax = F.softmax(trigger_pred, dim=-1)
        # B,K,C
        # trigger_pred = self.trigger_classification(hidden_trigger)

        # argument classify
        Ba, M, Da = argument_embed.size()
        event_feature_a = torch.bmm(trigger_pred_softmax, event_feature)
        event_feature_a = event_feature_a.unsqueeze(2).repeat(1, 1, M, 1)  # B,K,M,D
        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([trigger_feature_a, argument_feature_a, event_feature_a], dim=-1)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r
        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)

        aa_hidden = torch.cat([argument_feature_aa1, argument_feature_aa2], dim=-1)
        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred


class dJHEE_pedal(BaseModel):

    def __init__(self, bert_path, bert_train, dropout, hidden_dim, role_num, event_num, arc_type_num, entity_type_num):
        super(dJHEE_pedal, self).__init__()
        self.bert = BertModel.from_pretrained(bert_path)
       
        for name, param in self.bert.named_parameters():
            param.requires_grad = False
        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        self.trigger_classification = nn.Linear(768 + self.hidden_dim, event_num)

        self.pedal_attention = Pedal_attention(768, 8)

        self.ta_classification = nn.Linear(768 * 2 + self.hidden_dim, role_num)
        self.aa_classification = nn.Linear(768 * 2 + self.hidden_dim, role_num)

        self.arc_embedding = nn.Embedding(arc_type_num, 100)  
        self.argument_type_embedding = nn.Embedding(entity_type_num, 100)  

        # self.trans_arc_words = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words = nn.Linear(768, self.hidden_dim)
        # self.trans_arc_words_a = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words_a = nn.Linear(768, self.hidden_dim)
        self.trans_arg_event = nn.Linear(768, self.hidden_dim)
        self.trans_arg_event_value = nn.Linear(768, self.hidden_dim)

        
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.dropout = nn.Dropout(dropout)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        tokens_embedding,cls_embedding = self.bert(bert_token_ids, attention_mask=bert_masks)

        # B,K
        trigger_mask = torch.sum(candidate_trigger, dim=-1)
        # B,M
        argument_mask = torch.sum(candidate_argument, dim=-1)
        # B,K,E - K,B,E
        trigger_related_mask = torch.sum(trigger_related, dim=-1).transpose(1, 0)
        # B,M,E1 - M,B,E1
        argument_related_mask = torch.sum(argument_related, dim=-1).transpose(1, 0)

        # K,B,E,DD
        trigger_arc_embed = self.arc_embedding(trigger_arc).transpose(1, 0)
        # M,B,E,DD
        argument_arc_embed = self.arc_embedding(argument_arc).transpose(1, 0)

        trigger_arc_mask_emb = trigger_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        trigger_arc_embed = trigger_arc_embed.masked_fill(trigger_arc_mask_emb == 0, 0.)

        argument_arc_mask_emb = argument_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        argument_arc_embed = argument_arc_embed.masked_fill(argument_arc_mask_emb == 0, 0.)

        trigger_related_embed = trigger_related.transpose(1, 0).matmul(tokens_embedding)

        # trigger_arc_value = self.trans_arc_words(torch.cat([trigger_related_embed, trigger_arc_embed], dim=-1))
        trigger_arc_value = self.trans_arc_words(trigger_related_embed)

        argument_related_embed = argument_related.transpose(1, 0).matmul(tokens_embedding)
        argument_arc_value = self.trans_arc_words_a(argument_related_embed)
        # argument_arc_value = self.trans_arc_words_a(torch.cat([argument_related_embed, argument_arc_embed], dim=-1))

        # embedding of candidate

        # K,B,M,D
        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)
        # B,KK,DD
        relation = self.pedal_attention(argument_embed, trigger_related_embed, trigger_arc_value,
                                        trigger_related_mask).transpose(1, 0)
        B, K, M, D = relation.size()

        trigger_relation = F.max_pool2d(relation, kernel_size=(M, 1)).reshape(B, K, D)

        trigger_feature = torch.cat([trigger_relation, trigger_embed], dim=-1)

        Bt, Kt, Dt = trigger_feature.size()

        hidden_trigger = trigger_feature
        trigger_mask_class = trigger_mask.unsqueeze(2).repeat(1, 1, Dt)
        hidden_trigger.masked_fill(trigger_mask_class == 0, 0.)
        # Bt, Kt, Dt = trigger_feature.size()

        # B,K,C
        trigger_pred = self.trigger_classification(hidden_trigger)

        # argument classify
        Ba, M, Da = argument_embed.size()

        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([trigger_feature_a, argument_feature_a, relation], dim=-1)
        B, K, M, Dta = ta_hidden.size()
        trigger_mask_ta = trigger_mask.unsqueeze(2).repeat(1, 1, M)
        trigger_mask_ta = trigger_mask_ta.unsqueeze(3).repeat(1, 1, 1, Dta)
        ta_hidden = ta_hidden.masked_fill(trigger_mask_ta == 0, 0.)

        arg_mask_ta = argument_mask.unsqueeze(2).repeat(1, 1, Dta)
        arg_mask_ta = arg_mask_ta.unsqueeze(1).repeat(1, K, 1, 1)
        ta_hidden = ta_hidden.masked_fill(arg_mask_ta == 0, 0.)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r
        relation_aa = self.pedal_attention(argument_embed, argument_related_embed, argument_arc_value,
                                           argument_related_mask).transpose(1, 0)

        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)

        aa_hidden = torch.cat([argument_feature_aa1, argument_feature_aa2, relation_aa], dim=-1)
        B, M, M, Daa = aa_hidden.size()
        arg_mask_aa = argument_mask.unsqueeze(2).repeat(1, 1, Daa)
        arg_mask_aa = arg_mask_aa.unsqueeze(1).repeat(1, M, 1, 1)
        aa_hidden = aa_hidden.masked_fill(arg_mask_aa == 0, 0.)

        arg_mask_aa2 = argument_mask.unsqueeze(2).repeat(1, 1, M)
        arg_mask_aa2 = arg_mask_aa2.unsqueeze(3).repeat(1, 1, 1, Daa)
        aa_hidden = aa_hidden.masked_fill(arg_mask_aa2 == 0, 0.)

        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred,cls_embedding


class TransformersdJHEE_pedal_HE(BaseModel):

    def __init__(self, transformer_model, cache_dir, force_download, is_train, dropout, hidden_dim, role_num,
                 relation_num, event_num, arc_type_num, entity_type_num):
        super(TransformersdJHEE_pedal_HE, self).__init__()
        self.transformer_model = BertModel.from_pretrained(transformer_model, cache_dir=cache_dir,
                                                           force_download=force_download)

        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        # self.trigger_classification = nn.Linear(768 + self.hidden_dim, event_num)
        self.trigger_classification_W = nn.Parameter(
            torch.Tensor(self.event_num,
                         self.transformer_model.config.to_dict()['hidden_size'] + self.hidden_dim * 2).uniform_(-0.1,
                                                                                                                0.1))
        self.pedal_attention = Pedal_attention(self.transformer_model.config.to_dict()['hidden_size'], 8)
        self.trigger_classification_b = nn.Parameter(torch.Tensor(self.event_num).uniform_(-0.1, 0.1))

        self.ta_classification = nn.Linear(
            self.transformer_model.config.to_dict()['hidden_size'] * 2 + self.hidden_dim * 3 + 100, role_num)
        self.aa_classification = nn.Linear(
            self.transformer_model.config.to_dict()['hidden_size'] * 2 + self.hidden_dim * 2 + 200, relation_num)

        self.arc_embedding = nn.Embedding(arc_type_num, 100)  
        self.argument_type_embedding = nn.Embedding(entity_type_num, 100) 

        # self.trans_arc_words = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        # self.trans_arc_words_a = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words_a = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.trans_arg_event = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.trans_arg_event_value = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)

        
        for name, param in self.transformer_model.named_parameters():
            param.requires_grad = is_train

        self.dropout = nn.Dropout(dropout)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        tokens_embedding = self.transformer_model(bert_token_ids, attention_mask=bert_masks)[0]

        # B,K
        trigger_mask = torch.sum(candidate_trigger, dim=-1)
        # B,M
        argument_mask = torch.sum(candidate_argument, dim=-1)
        # B,K,E - K,B,E
        trigger_related_mask = torch.sum(trigger_related, dim=-1).transpose(1, 0)
        # B,M,E1 - M,B,E1
        argument_related_mask = torch.sum(argument_related, dim=-1).transpose(1, 0)

        # K,B,E,DD
        trigger_arc_embed = self.arc_embedding(trigger_arc).transpose(1, 0)
        # M,B,E,DD
        argument_arc_embed = self.arc_embedding(argument_arc).transpose(1, 0)

        trigger_arc_mask_emb = trigger_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        trigger_arc_embed = trigger_arc_embed.masked_fill(trigger_arc_mask_emb == 0, 0.)

        argument_arc_mask_emb = argument_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        argument_arc_embed = argument_arc_embed.masked_fill(argument_arc_mask_emb == 0, 0.)

        trigger_related_embed = trigger_related.transpose(1, 0).matmul(tokens_embedding)

        # trigger_arc_value = self.trans_arc_words(torch.cat([trigger_related_embed, trigger_arc_embed], dim=-1))
        trigger_arc_value = self.trans_arc_words(trigger_related_embed)

        argument_related_embed = argument_related.transpose(1, 0).matmul(tokens_embedding)
        argument_arc_value = self.trans_arc_words_a(argument_related_embed)
        # argument_arc_value = self.trans_arc_words_a(torch.cat([argument_related_embed, argument_arc_embed], dim=-1))

        # embedding of candidate

        # K,B,M,D

        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)

        argument_type_embed = self.argument_type_embedding(argument_type)

        # B,KK,DD
        relation = self.pedal_attention(argument_embed, trigger_related_embed, trigger_arc_value,
                                        trigger_related_mask).transpose(1, 0)
        B, K, M, D = relation.size()

        trigger_relation = F.max_pool2d(relation, kernel_size=(M, 1)).reshape(B, K, D)

        # trigger classify
        event_weight = self.HE(self.trans_arg_event(argument_embed))
        # B,C,M

        event_feature = event_weight.matmul(self.trans_arg_event_value(argument_embed))
        Be, Ce, De = event_feature.size()
        trigger_feature = torch.cat([trigger_relation, trigger_embed], dim=-1)

        Bt, Kt, Dt = trigger_feature.size()

        trigger_mask_class = trigger_mask.unsqueeze(2).repeat(1, 1, Dt)
        trigger_feature.masked_fill(trigger_mask_class == 0, 0.)

        event_feature_t = event_feature.unsqueeze(1).repeat(1, Kt, 1, 1).reshape(Be, Kt, Ce, De)
        trigger_feature = trigger_feature.unsqueeze(2).repeat(1, 1, Ce, 1).reshape(Bt, Kt, Ce, Dt)

        # Bt, Kt, Dt = trigger_feature.size()

        hidden_trigger = torch.cat([event_feature_t, trigger_feature], dim=-1)

        trigger_pred = torch.sum(hidden_trigger * self.trigger_classification_W, -1) + self.trigger_classification_b
        trigger_pred_softmax = F.softmax(trigger_pred, dim=-1)
        # B,K,C
        # trigger_pred = self.trigger_classification(hidden_trigger)

        # argument classify
        Ba, M, Da = argument_embed.size()

        event_feature_a = torch.bmm(trigger_pred_softmax, event_feature)
        event_feature_a = event_feature_a.unsqueeze(2).repeat(1, 1, M, 1)
        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)
        argument_type_embed_a = argument_type_embed.unsqueeze(1).repeat(1, K, 1, 1)

        relation_aa = self.pedal_attention(argument_embed, argument_related_embed, argument_arc_value,
                                           argument_related_mask).transpose(1, 0)
        argument_relation_ta = F.max_pool2d(relation_aa, kernel_size=(M, 1)).reshape(B, M, D).unsqueeze(
            1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([event_feature_a, trigger_feature_a, argument_type_embed_a, argument_feature_a, relation,
                               argument_relation_ta],
                              dim=-1)
        B, K, M, Dta = ta_hidden.size()
        trigger_mask_ta = trigger_mask.unsqueeze(2).repeat(1, 1, M)
        trigger_mask_ta = trigger_mask_ta.unsqueeze(3).repeat(1, 1, 1, Dta)
        ta_hidden = ta_hidden.masked_fill(trigger_mask_ta == 0, 0.)

        arg_mask_ta = argument_mask.unsqueeze(2).repeat(1, 1, Dta)
        arg_mask_ta = arg_mask_ta.unsqueeze(1).repeat(1, K, 1, 1)
        ta_hidden = ta_hidden.masked_fill(arg_mask_ta == 0, 0.)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r

        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_type_embed_aa1 = argument_type_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_type_embed_aa2 = argument_type_embed.unsqueeze(1).repeat(1, M, 1, 1)

        argument_relation_aa = F.max_pool2d(relation_aa, kernel_size=(M, 1)).reshape(B, M, D).unsqueeze(
            1).repeat(1, M, 1, 1)

        aa_hidden = torch.cat(
            [argument_type_embed_aa1, argument_feature_aa1, argument_type_embed_aa2, argument_feature_aa2, relation_aa,
             argument_relation_aa],
            dim=-1)
        B, M, M, Daa = aa_hidden.size()
        arg_mask_aa = argument_mask.unsqueeze(2).repeat(1, 1, Daa)
        arg_mask_aa = arg_mask_aa.unsqueeze(1).repeat(1, M, 1, 1)
        aa_hidden = aa_hidden.masked_fill(arg_mask_aa == 0, 0.)

        arg_mask_aa2 = argument_mask.unsqueeze(2).repeat(1, 1, M)
        arg_mask_aa2 = arg_mask_aa2.unsqueeze(3).repeat(1, 1, 1, Daa)
        aa_hidden = aa_hidden.masked_fill(arg_mask_aa2 == 0, 0.)

        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred


class TransformersDJHEE(BaseModel):

    def __init__(self, transformer_model, cache_dir, force_download, is_train, dropout, hidden_dim, role_num,
                 relation_num, event_num, arc_type_num, entity_type_num):
        super(TransformersDJHEE, self).__init__()
        self.transformer_model = AutoModel.from_pretrained(transformer_model, cache_dir=cache_dir,
                                                           force_download=force_download)

        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        # self.trigger_classification = nn.Linear(768 + self.hidden_dim, event_num)
        self.trigger_classification_W = nn.Parameter(
            torch.Tensor(self.event_num,
                         self.transformer_model.config.to_dict()['hidden_size'] + self.hidden_dim * 2).uniform_(-0.1,
                                                                                                                0.1))
        self.pedal_attention = Pedal_attention(self.transformer_model.config.to_dict()['hidden_size'], 8)
        self.trigger_classification_b = nn.Parameter(torch.Tensor(self.event_num).uniform_(-0.1, 0.1))

        self.ta_classification = nn.Linear(
            self.transformer_model.config.to_dict()['hidden_size'] * 2 + self.hidden_dim * 3 + 100, role_num)
        self.aa_classification = nn.Linear(
            self.transformer_model.config.to_dict()['hidden_size'] * 2 + self.hidden_dim * 2 + 200, relation_num)

        self.arc_embedding = nn.Embedding(arc_type_num, 100)  
        self.argument_type_embedding = nn.Embedding(entity_type_num, 100)  

        # self.trans_arc_words = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        # self.trans_arc_words_a = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words_a = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.trans_arg_event = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.trans_arg_event_value = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)

        
        for name, param in self.transformer_model.named_parameters():
            param.requires_grad = is_train

        self.dropout = nn.Dropout(dropout)

        self.loss_pred = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'],1)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        tokens_embedding,cls_embedding = self.transformer_model(bert_token_ids, attention_mask=bert_masks)

        # B,K
        trigger_mask = torch.sum(candidate_trigger, dim=-1)
        # B,M
        argument_mask = torch.sum(candidate_argument, dim=-1)
        # B,K,E - K,B,E
        trigger_related_mask = torch.sum(trigger_related, dim=-1).transpose(1, 0)
        # B,M,E1 - M,B,E1
        argument_related_mask = torch.sum(argument_related, dim=-1).transpose(1, 0)

        # K,B,E,DD
        trigger_arc_embed = self.arc_embedding(trigger_arc).transpose(1, 0)
        # M,B,E,DD
        argument_arc_embed = self.arc_embedding(argument_arc).transpose(1, 0)

        trigger_arc_mask_emb = trigger_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        trigger_arc_embed = trigger_arc_embed.masked_fill(trigger_arc_mask_emb == 0, 0.)

        argument_arc_mask_emb = argument_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        argument_arc_embed = argument_arc_embed.masked_fill(argument_arc_mask_emb == 0, 0.)

        trigger_related_embed = trigger_related.transpose(1, 0).matmul(tokens_embedding)

        # trigger_arc_value = self.trans_arc_words(torch.cat([trigger_related_embed, trigger_arc_embed], dim=-1))
        trigger_arc_value = self.trans_arc_words(trigger_related_embed)

        argument_related_embed = argument_related.transpose(1, 0).matmul(tokens_embedding)
        argument_arc_value = self.trans_arc_words_a(argument_related_embed)
        # argument_arc_value = self.trans_arc_words_a(torch.cat([argument_related_embed, argument_arc_embed], dim=-1))

        # embedding of candidate

        # K,B,M,D

        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)

        argument_type_embed = self.argument_type_embedding(argument_type)

        # B,KK,DD
        relation = self.pedal_attention(argument_embed, trigger_related_embed, trigger_arc_value,
                                        trigger_related_mask).transpose(1, 0)
        B, K, M, D = relation.size()

        trigger_relation = F.max_pool2d(relation, kernel_size=(M, 1)).reshape(B, K, D)

        # trigger classify
        event_weight = self.HE(self.trans_arg_event(argument_embed))
        # B,C,M

        event_feature = event_weight.matmul(self.trans_arg_event_value(argument_embed))
        Be, Ce, De = event_feature.size()
        trigger_feature = torch.cat([trigger_relation, trigger_embed], dim=-1)

        Bt, Kt, Dt = trigger_feature.size()

        trigger_mask_class = trigger_mask.unsqueeze(2).repeat(1, 1, Dt)
        trigger_feature.masked_fill(trigger_mask_class == 0, 0.)

        event_feature_t = event_feature.unsqueeze(1).repeat(1, Kt, 1, 1).reshape(Be, Kt, Ce, De)
        trigger_feature = trigger_feature.unsqueeze(2).repeat(1, 1, Ce, 1).reshape(Bt, Kt, Ce, Dt)

        # Bt, Kt, Dt = trigger_feature.size()

        hidden_trigger = torch.cat([event_feature_t, trigger_feature], dim=-1)

        trigger_pred = torch.sum(hidden_trigger * self.trigger_classification_W, -1) + self.trigger_classification_b
        trigger_pred_softmax = F.log_softmax(trigger_pred, dim=-1)
        # B,K,C
        # trigger_pred = self.trigger_classification(hidden_trigger)

        # argument classify
        Ba, M, Da = argument_embed.size()

        event_feature_a = torch.bmm(trigger_pred_softmax, event_feature)
        event_feature_a = event_feature_a.unsqueeze(2).repeat(1, 1, M, 1)
        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)
        argument_type_embed_a = argument_type_embed.unsqueeze(1).repeat(1, K, 1, 1)

        relation_aa = self.pedal_attention(argument_embed, argument_related_embed, argument_arc_value,
                                           argument_related_mask).transpose(1, 0)
        argument_relation_ta = F.max_pool2d(relation_aa, kernel_size=(M, 1)).reshape(B, M, D).unsqueeze(
            1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([event_feature_a, trigger_feature_a, argument_type_embed_a, argument_feature_a, relation,
                               argument_relation_ta],
                              dim=-1)
        B, K, M, Dta = ta_hidden.size()
        trigger_mask_ta = trigger_mask.unsqueeze(2).repeat(1, 1, M)
        trigger_mask_ta = trigger_mask_ta.unsqueeze(3).repeat(1, 1, 1, Dta)
        ta_hidden = ta_hidden.masked_fill(trigger_mask_ta == 0, 0.)

        arg_mask_ta = argument_mask.unsqueeze(2).repeat(1, 1, Dta)
        arg_mask_ta = arg_mask_ta.unsqueeze(1).repeat(1, K, 1, 1)
        ta_hidden = ta_hidden.masked_fill(arg_mask_ta == 0, 0.)
        ta_pred = self.ta_classification(ta_hidden)

        pred_loss = self.loss_pred(cls_embedding).squeeze()

        return trigger_pred, ta_pred,cls_embedding,pred_loss





class DMCNN(BaseModel):

    def __init__(self, bert_path, bert_train, dropout, hidden_dim, role_num, event_num, n_filters, filter_sizes,
                 arc_type_num, entity_type_num):
        super(DMCNN, self).__init__()
        self.bert = BertModel.from_pretrained(bert_path)
        
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        self.trigger_classification = nn.Linear(768, event_num)
        self.conv = nn.Conv2d(in_channels=1, out_channels=1, kernel_size=(3, 1), padding=(1, 0))
        self.ta_classification = nn.Linear(768 * 2, role_num)
        self.aa_classification = nn.Linear(768 * 2, role_num)
        self.dropout = nn.Dropout(dropout)


    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        # B L 768
        tokens_embedding = self.bert(bert_token_ids, attention_mask=bert_masks)[0]
        tokens_embedding = tokens_embedding.unsqueeze(1)
        tokens_embedding = F.relu(self.conv(tokens_embedding)).squeeze()
        # embedding of candidate
        # K,B,M,D
        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)
        # B,KK,DD
        #
        hidden_trigger = trigger_embed

        # B,K,C
        trigger_pred = self.trigger_classification(hidden_trigger)

        B, K, C = trigger_pred.size()

        # argument classify
        Ba, M, Da = argument_embed.size()

        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([trigger_feature_a, argument_feature_a], dim=-1)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r
        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)

        aa_hidden = torch.cat([argument_feature_aa1, argument_feature_aa2], dim=-1)
        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred


class DBRNN(BaseModel):

    def __init__(self, bert_path, bert_train, dropout, hidden_dim, role_num, event_num, arc_type_num, entity_type_num):
        super(DBRNN, self).__init__()
        self.bert = BertModel.from_pretrained(bert_path)
        
        for name, param in self.bert.named_parameters():
            param.requires_grad = bert_train
        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        self.trigger_classification = nn.Linear(768 * 2, event_num)
        self.ta_classification = nn.Linear(768 * 4, role_num)
        self.aa_classification = nn.Linear(768 * 4, role_num)
        self.dropout = nn.Dropout(dropout)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,  # B,M,E1,N
                ):
        # B L 768
        tokens_embedding = self.bert(bert_token_ids, attention_mask=bert_masks)[0]

        # embedding of candidate
        B, K, E, L = trigger_related.shape

        
        trigger_related_embed = trigger_related.transpose(1, 0).matmul(tokens_embedding).transpose(1, 0)
        trigger_related = F.max_pool2d(trigger_related_embed, kernel_size=(E, 1)).squeeze()

        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)  # B,K ,768
        trigger_embed = torch.cat([trigger_embed, trigger_related], dim=-1)  # B,K ,(768*2)

        # B,KK,D
        
        B, M, E1, L = argument_related.shape
        argument_related_embed = argument_related.transpose(1, 0).matmul(tokens_embedding).transpose(1, 0)
        argument_related = F.max_pool2d(argument_related_embed, kernel_size=(E1, 1)).squeeze()
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)
        argument_embed = torch.cat([argument_embed, argument_related], dim=-1)  # B,M,(768*2)
        # B,KK,DD
        #
        hidden_trigger = trigger_embed

        # B,K,C
        trigger_pred = self.trigger_classification(hidden_trigger)

        B, K, C = trigger_pred.size()

        # argument classify
        # argument classify
        Ba, M, Da = argument_embed.size()

        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([trigger_feature_a, argument_feature_a], dim=-1)
        ta_pred = self.ta_classification(ta_hidden)

        # a-a-r
        argument_feature_aa2 = argument_embed.unsqueeze(1).repeat(1, M, 1, 1)
        argument_feature_aa1 = argument_embed.unsqueeze(2).repeat(1, 1, M, 1)

        aa_hidden = torch.cat([argument_feature_aa1, argument_feature_aa2], dim=-1)
        aa_pred = self.aa_classification(aa_hidden)
        return trigger_pred, ta_pred, aa_pred



class transformersdelayDJHEE(BaseModel):

    def __init__(self, transformer_model, cache_dir, force_download, is_train, dropout, hidden_dim, role_num,
                 relation_num, event_num, arc_type_num, entity_type_num):
        super(transformersdelayDJHEE, self).__init__()
        self.transformer_model = BertModel.from_pretrained(transformer_model, cache_dir=cache_dir,
                                                           force_download=force_download)

        self.hidden_dim = hidden_dim  # 256
        self.HE = HE_feature(self.hidden_dim)
        self.event_num = event_num  # 12
        # self.trigger_classification = nn.Linear(768 + self.hidden_dim, event_num)
        self.trigger_classification_W = nn.Parameter(
            torch.Tensor(self.event_num,
                         self.transformer_model.config.to_dict()['hidden_size'] + self.hidden_dim * 2).uniform_(-0.1,
                                                                                                                0.1))
        self.pedal_attention = Pedal_attention(self.transformer_model.config.to_dict()['hidden_size'], 8)
        self.trigger_classification_b = nn.Parameter(torch.Tensor(self.event_num).uniform_(-0.1, 0.1))

        self.ta_classification = nn.Linear(
            self.transformer_model.config.to_dict()['hidden_size'] * 2 + self.hidden_dim * 3 + 100, role_num)
        self.aa_classification = nn.Linear(
            self.transformer_model.config.to_dict()['hidden_size'] * 2 + self.hidden_dim * 2 + 200, relation_num)

        self.arc_embedding = nn.Embedding(arc_type_num, 100)  
        self.argument_type_embedding = nn.Embedding(entity_type_num, 100)  

        # self.trans_arc_words = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        # self.trans_arc_words_a = nn.Linear(768 + 100, self.hidden_dim)
        self.trans_arc_words_a = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.trans_arg_event = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.trans_arg_event_value = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)

       
        for name, param in self.transformer_model.named_parameters():
            param.requires_grad = is_train

        self.dropout = nn.Dropout(dropout)

        self.t_entropy_weight_ = torch.ones(12).cuda()
        self.t_entropy_weight_[0] = 0.01
        self.ta_entropy_weight_ = torch.ones(24).cuda()
        self.ta_entropy_weight_[0] = 0.01
        self.aa_entropy_weight_ = torch.ones(18).cuda()
        self.aa_entropy_weight_[0] = 0.01

        self.LM_memory = torch.cuda.FloatTensor(self.hidden_dim).uniform_(-0.1, 0.1)

        

        self.LM_att = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], 1)
        self.LM_trans = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)
        self.LM_gate = nn.Linear(self.hidden_dim * 2, 1)

        self.SM_att = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], 1)
        self.SM_trans = nn.Linear(self.transformer_model.config.to_dict()['hidden_size'], self.hidden_dim)

        self.loss_pred = nn.Linear(self.hidden_dim * 2 + self.transformer_model.config.to_dict()['hidden_size'], 1)

    def forward(self, bert_token_ids,  # B,N
                bert_token_lengths,
                bert_masks,
                candidate_trigger,  # B,K,N
                candidate_argument,  # B,M,N
                argument_type,  # B,M
                trigger_arc,  # B,K,E
                trigger_related,  # B,K,E,N
                argument_arc,  # B,M,E1
                argument_related,
                batch_idx,
                trigger_labels,
                trigger_argument_labels,
                criterion,
                last_cls,
                last_last_cls,
                istrain
                ):
        tokens_embedding, cls_embedding = self.transformer_model(bert_token_ids, attention_mask=bert_masks)

        # B,K
        trigger_mask = torch.sum(candidate_trigger, dim=-1)
        # B,M
        argument_mask = torch.sum(candidate_argument, dim=-1)
        # B,K,E - K,B,E
        trigger_related_mask = torch.sum(trigger_related, dim=-1).transpose(1, 0)
        # B,M,E1 - M,B,E1
        argument_related_mask = torch.sum(argument_related, dim=-1).transpose(1, 0)

        # K,B,E,DD
        trigger_arc_embed = self.arc_embedding(trigger_arc).transpose(1, 0)
        # M,B,E,DD
        argument_arc_embed = self.arc_embedding(argument_arc).transpose(1, 0)

        trigger_arc_mask_emb = trigger_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        trigger_arc_embed = trigger_arc_embed.masked_fill(trigger_arc_mask_emb == 0, 0.)

        argument_arc_mask_emb = argument_arc.unsqueeze(3).repeat(1, 1, 1, 100).transpose(1, 0)
        argument_arc_embed = argument_arc_embed.masked_fill(argument_arc_mask_emb == 0, 0.)

        trigger_related_embed = trigger_related.transpose(1, 0).matmul(tokens_embedding)

        # trigger_arc_value = self.trans_arc_words(torch.cat([trigger_related_embed, trigger_arc_embed], dim=-1))
        trigger_arc_value = self.trans_arc_words(trigger_related_embed)

        argument_related_embed = argument_related.transpose(1, 0).matmul(tokens_embedding)
        argument_arc_value = self.trans_arc_words_a(argument_related_embed)
        # argument_arc_value = self.trans_arc_words_a(torch.cat([argument_related_embed, argument_arc_embed], dim=-1))

        # embedding of candidate

        # K,B,M,D

        trigger_embed = torch.bmm(candidate_trigger, tokens_embedding)
        # B,KK,D
        argument_embed = torch.bmm(candidate_argument, tokens_embedding)

        argument_type_embed = self.argument_type_embedding(argument_type)

        # B,KK,DD
        relation = self.pedal_attention(argument_embed, trigger_related_embed, trigger_arc_value,
                                        trigger_related_mask).transpose(1, 0)
        B, K, M, D = relation.size()

        trigger_relation = F.max_pool2d(relation, kernel_size=(M, 1)).reshape(B, K, D)

        # trigger classify
        event_weight = self.HE(self.trans_arg_event(argument_embed))
        # B,C,M

        event_feature = event_weight.matmul(self.trans_arg_event_value(argument_embed))
        Be, Ce, De = event_feature.size()
        trigger_feature = torch.cat([trigger_relation, trigger_embed], dim=-1)

        Bt, Kt, Dt = trigger_feature.size()

        trigger_mask_class = trigger_mask.unsqueeze(2).repeat(1, 1, Dt)
        trigger_feature.masked_fill(trigger_mask_class == 0, 0.)

        event_feature_t = event_feature.unsqueeze(1).repeat(1, Kt, 1, 1).reshape(Be, Kt, Ce, De)
        trigger_feature = trigger_feature.unsqueeze(2).repeat(1, 1, Ce, 1).reshape(Bt, Kt, Ce, Dt)

        # Bt, Kt, Dt = trigger_feature.size()

        hidden_trigger = torch.cat([event_feature_t, trigger_feature], dim=-1)

        trigger_pred = torch.sum(hidden_trigger * self.trigger_classification_W, -1) + self.trigger_classification_b
        trigger_pred_softmax = F.softmax(trigger_pred, dim=-1)
        # B,K,C
        # trigger_pred = self.trigger_classification(hidden_trigger)

        # argument classify
        Ba, M, Da = argument_embed.size()

        event_feature_a = torch.bmm(trigger_pred_softmax, event_feature)
        event_feature_a = event_feature_a.unsqueeze(2).repeat(1, 1, M, 1)
        trigger_feature_a = trigger_embed.unsqueeze(2).repeat(1, 1, M, 1)
        argument_feature_a = argument_embed.unsqueeze(1).repeat(1, K, 1, 1)
        argument_type_embed_a = argument_type_embed.unsqueeze(1).repeat(1, K, 1, 1)

        relation_aa = self.pedal_attention(argument_embed, argument_related_embed, argument_arc_value,
                                           argument_related_mask).transpose(1, 0)
        argument_relation_ta = F.max_pool2d(relation_aa, kernel_size=(M, 1)).reshape(B, M, D).unsqueeze(
            1).repeat(1, K, 1, 1)

        ta_hidden = torch.cat([event_feature_a, trigger_feature_a, argument_type_embed_a, argument_feature_a, relation,
                               argument_relation_ta],
                              dim=-1)
        B, K, M, Dta = ta_hidden.size()
        trigger_mask_ta = trigger_mask.unsqueeze(2).repeat(1, 1, M)
        trigger_mask_ta = trigger_mask_ta.unsqueeze(3).repeat(1, 1, 1, Dta)
        ta_hidden = ta_hidden.masked_fill(trigger_mask_ta == 0, 0.)

        arg_mask_ta = argument_mask.unsqueeze(2).repeat(1, 1, Dta)
        arg_mask_ta = arg_mask_ta.unsqueeze(1).repeat(1, K, 1, 1)
        ta_hidden = ta_hidden.masked_fill(arg_mask_ta == 0, 0.)
        ta_pred = self.ta_classification(ta_hidden)

        total_loss = None

        if not istrain == 3:
            trigger_loss = criterion[0](trigger_pred, trigger_labels, weight=self.t_entropy_weight_,
                                        reduction='none')
            trigger_argument_loss = criterion[1](ta_pred, trigger_argument_labels, weight=self.ta_entropy_weight_,
                                                 reduction='none')

            trigger_loss = torch.mean(trigger_loss, dim=-1)
            ta_loss = torch.mean(trigger_argument_loss, dim=-1)
            ta_loss = torch.mean(ta_loss, dim=-1)
            target_loss = trigger_loss + ta_loss
            total_loss = target_loss.mean()

        moudle_loss = 0
        pre_loss = 0

        # memory update SM
        if batch_idx > 1:
            if istrain == 1:
                
                SM_a = nn.Softmax(-1)(self.SM_att(last_cls.detach())).view(last_cls.size()[0], 1)
                SM_v = self.SM_trans(last_cls.detach()).view(last_cls.size()[0], self.hidden_dim)
                SM_memory = torch.mm(SM_a.transpose(1, 0).view(1, last_cls.size()[0]), SM_v).view(self.hidden_dim)

               

                LM_a = nn.Softmax(-1)(self.LM_att(last_last_cls.detach())).view(-1, 1)
                LM_v = self.LM_trans(last_last_cls.detach()).view(-1, self.hidden_dim)
                LM_new = torch.mm(LM_a.transpose(1, 0), LM_v).view(self.hidden_dim)
                LM_g = nn.Sigmoid()(self.LM_gate(torch.cat([self.LM_memory.detach(), LM_new])))
                self.LM_memory = self.LM_memory.detach() * (1 - LM_g) + LM_new * LM_g

                memory = torch.cat([SM_memory, self.LM_memory]).unsqueeze(0).repeat(B, 1)

                pre_loss = self.loss_pred(torch.cat([cls_embedding, memory], -1)).squeeze()

                module_loss = LossPredLoss(pre_loss, target_loss.detach())
                total_loss = target_loss.mean() + module_loss * 0.01
            if istrain == 3:  # active
                SM_a = nn.Softmax(-1)(self.SM_att(last_cls.detach())).view(last_cls.size()[0], 1)
                SM_v = self.SM_trans(last_cls.detach()).view(last_cls.size()[0], self.hidden_dim)
                SM_memory = torch.mm(SM_a.transpose(1, 0).view(1, last_cls.size()[0]), SM_v).view(self.hidden_dim)

                memory = torch.cat([SM_memory, self.LM_memory]).unsqueeze(0).repeat(B, 1)

                pre_loss = self.loss_pred(torch.cat([cls_embedding, memory], -1)).squeeze()

                # module_loss = LossPredLoss(pre_loss, target_loss.detach())
                # total_loss = target_loss.mean() + module_loss * 0.001

        return trigger_pred, ta_pred, cls_embedding, total_loss, moudle_loss, pre_loss


