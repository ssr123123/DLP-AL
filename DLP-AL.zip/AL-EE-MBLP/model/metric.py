
import torch
from sklearn.metrics import f1_score, precision_score, recall_score, accuracy_score
import numpy as np


def tag_accuracy(preds, labels):
    scores = []
    for pred, label in zip(preds, labels):
        scores.append(accuracy_score(pred, label))
    return sum(scores) / len(scores)


def get_numpy(pred, label):
    pred = pred.argmax(dim=-1).squeeze()
    pred = torch.flatten(pred, start_dim=0, end_dim=-1)
    label = torch.flatten(label, start_dim=0, end_dim=-1)

    zeros = torch.zeros_like(label)
    ones = torch.ones_like(label)
    mask = torch.where(label > 0, ones, zeros).bool()
    pred = torch.masked_select(pred, mask).cpu().numpy()
    label = torch.masked_select(label, mask).cpu().numpy()
    return pred, label


def batch_precision(pred, label):
    pred, label = get_numpy(pred, label)

    return precision_score(pred, label, average='weighted')


def batch_recall(pred, label):
    pred, label = get_numpy(pred, label)
    return recall_score(pred, label, average='weighted')


def batch_f1(pred, label):
    pred, label = get_numpy(pred, label)
    return f1_score(pred, label, average='weighted')


def idification_precision(pred, label):
    pred, label = get_numpy(pred, label)
    pred = np.where(pred > 1, 1, 0)
    label = np.where(label > 1, 1, 0)
    return precision_score(pred, label)


def idification_recall(pred, label):
    pred, label = get_numpy(pred, label)
    pred = np.where(pred > 1, 1, 0)
    label = np.where(label > 1, 1, 0)
    return recall_score(pred, label)


def idification_f1(pred, label):
    pred, label = get_numpy(pred, label)
    pred = np.where(pred > 1, 1, 0)
    label = np.where(label > 1, 1, 0)
    return f1_score(pred, label)


def binary_accuracy(preds, y):
    """
    Returns accuracy per batch, i.e. if you get 8/10 right, this returns 0.8, NOT 8
    """

    # round predictions to the closest integer
    rounded_preds = torch.round(torch.sigmoid(preds))
    correct = (rounded_preds == y).float()  # convert into float for division
    acc = correct.sum() / len(correct)
    return acc


def categorical_accuracy(preds, y):
    """
    Returns accuracy per batch, i.e. if you get 8/10 right, this returns 0.8, NOT 8
    """
    max_preds = preds.argmax(dim=-1).squeeze(1)  # get the index of the max probability
    max_preds = torch.flatten(max_preds, start_dim=0, end_dim=-1)
    y = torch.flatten(y, start_dim=0, end_dim=-1)
    zeros_like = torch.zeros_like(y)
    ones_like = torch.ones_like(y)
    mask_y = torch.where(y > 0, ones_like, zeros_like).bool()
    y = torch.masked_select(y, mask_y)
    max_preds = torch.masked_select(max_preds, mask_y)
    correct = max_preds.eq(y)
    return (correct.sum() / torch.FloatTensor([y.shape[0]]).cuda()).item()

# def argument_categorical_accuracy(preds, y):
#     """
#     Returns accuracy per batch, i.e. if you get 8/10 right, this returns 0.8, NOT 8
#     """
#     max_preds = preds.argmax(dim=-1)  # get the index of the max probability
#     correct = max_preds.squeeze(1).eq(y)
#     return (correct.sum() / torch.FloatTensor([y.shape[0]])).item()
