
import numpy as np
import torch
from torch.nn import functional as F
from base import BaseTrainer
from utils import inf_loop, MetricTracker
from time import time
import json
from model.metric import batch_f1, batch_precision, batch_recall, idification_precision, idification_recall, \
    idification_f1
import copy


class Trainer(BaseTrainer):
    """
    """

    def __init__(self, model, criterion, metric_ftns, optimizer, config, train_iter, valid_iter, test_iter=None,
                 lr_scheduler=None, len_epoch=None):
        super().__init__(model, criterion, metric_ftns, optimizer, config)
        self.config = config
        self.train_iter, self.valid_iter, self.test_iter = train_iter, valid_iter, test_iter
        if len_epoch is None:
            # epoch-based training
            self.len_epoch = len(self.train_iter)
        else:
            # iteration-based training
            self.data_loader = inf_loop(train_iter)
            self.len_epoch = len_epoch

        self.do_validation = self.valid_iter is not None
        self.lr_scheduler = lr_scheduler
        self.log_step = int(np.sqrt(train_iter.batch_size))

        self.train_metrics = MetricTracker('trigger_loss', 'trigger_argument_loss', 'argument_argument_loss',
                                           'total_loss', 'trigger_acc', 'trigger_argument_acc', 'argument_argument_acc',
                                           'trigger_p', 'trigger_r', 'trigger_f',
                                           'idification_trigger_p', 'idification_trigger_r', 'idification_trigger_f',
                                           'ta_p', 'ta_r', 'ta_f',
                                           'idification_ta_p', 'idification_ta_r', 'idification_ta_f',
                                           'aa_p', 'aa_r', 'aa_f',
                                           'idification_aa_p', 'idification_aa_r', 'idification_aa_f',
                                           writer=self.writer)
        self.valid_metrics = MetricTracker('trigger_loss', 'trigger_argument_loss', 'argument_argument_loss',
                                           'total_loss', 'trigger_acc', 'trigger_argument_acc', 'argument_argument_acc',
                                           'trigger_p', 'trigger_r', 'trigger_f',
                                           'idification_trigger_p', 'idification_trigger_r', 'idification_trigger_f',
                                           'ta_p', 'ta_r', 'ta_f',
                                           'idification_ta_p', 'idification_ta_r', 'idification_ta_f',
                                           'aa_p', 'aa_r', 'aa_f',
                                           'idification_aa_p', 'idification_aa_r', 'idification_aa_f',
                                           writer=self.writer)

    def _train_epoch(self, epoch):
        """
        Training logic for an epoch

        :param epoch: Integer, current training epoch.
        :return: A log that contains average loss and metric in this epoch.
        """
        t1 = time()
        self.model.train()
        self.train_metrics.reset()
        for batch_idx, batch_data in enumerate(self.train_iter):
            self.optimizer.zero_grad()
            input_ids, attention_masks, text_lengths, candidate_arguments, \
            candidate_argument_types, candidate_argument_arcs, candidate_argument_relateds, \
            candidate_triggers, candidate_trigger_arcs, candidate_trigger_relateds, \
            trigger_labels, trigger_argument_labels, argument_argument_labels = batch_data

            if 'cuda' == self.device.type:
                input_ids = input_ids.cuda()
                attention_masks = attention_masks.cuda()
                text_lengths = text_lengths.cuda()

                candidate_arguments = candidate_arguments.cuda()
                candidate_argument_types = candidate_argument_types.cuda()
                candidate_argument_arcs = candidate_argument_arcs.cuda()
                candidate_argument_relateds = candidate_argument_relateds.cuda()

                candidate_triggers = candidate_triggers.cuda()
                candidate_trigger_arcs = candidate_trigger_arcs.cuda()
                candidate_trigger_relateds = candidate_trigger_relateds.cuda()

                trigger_labels = trigger_labels.cuda()
                trigger_argument_labels = trigger_argument_labels.cuda()
                argument_argument_labels = argument_argument_labels.cuda()

            trigger_pred, ta_pred, aa_pred = self.model(input_ids,
                                                        text_lengths,
                                                        attention_masks,
                                                        candidate_triggers,
                                                        candidate_arguments,
                                                        candidate_argument_types,
                                                        candidate_trigger_arcs,
                                                        candidate_trigger_relateds,
                                                        candidate_argument_arcs,
                                                        candidate_argument_relateds
                                                        )
            self.t_entropy_weight_ = torch.ones(12).cuda()
            self.t_entropy_weight_[0] = 0.01
            self.ta_entropy_weight_ = torch.ones(24).cuda()
            self.ta_entropy_weight_[0] = 0.01
            self.aa_entropy_weight_ = torch.ones(18).cuda()
            self.aa_entropy_weight_[0] = 0.01
            # self.t_entropy_weight_ = None
            # self.ta_entropy_weight_ = None
            # self.aa_entropy_weight_ = None
            trigger_loss = self.criterion[0](trigger_pred, trigger_labels, weight=self.t_entropy_weight_)
            trigger_argument_loss = self.criterion[1](ta_pred, trigger_argument_labels, weight=self.ta_entropy_weight_)
            argument_argument_loss = self.criterion[1](aa_pred, argument_argument_labels,
                                                       weight=self.aa_entropy_weight_)
            total_loss = trigger_loss + trigger_argument_loss + argument_argument_loss
            total_loss.backward()
            self.optimizer.step()
            # get_trigger_text(trigger_labels,candidate_triggers, texts)
            # get_ta_text(trigger_argument_labels,candidate_argument_types,candidate_arguments,texts)
            # get_aa_text(argument_argument_labels,candidate_argument_types,candidate_arguments,texts)

            trigger_acc = self.metric_ftns[0](trigger_pred, trigger_labels)
            ta_acc = self.metric_ftns[0](ta_pred, trigger_argument_labels)
            aa_acc = self.metric_ftns[0](aa_pred, argument_argument_labels)

            self.writer.set_step((epoch - 1) * self.len_epoch + batch_idx)
            self.train_metrics.update('trigger_loss', trigger_loss.item())
            self.train_metrics.update('trigger_argument_loss', trigger_argument_loss.item())
            self.train_metrics.update('argument_argument_loss', argument_argument_loss.item())
            self.train_metrics.update('total_loss', total_loss.item())
            self.train_metrics.update('trigger_acc', trigger_acc)
            self.train_metrics.update('trigger_argument_acc', ta_acc)
            self.train_metrics.update('argument_argument_acc', aa_acc)

            trigger_p = batch_precision(trigger_pred, trigger_labels)
            trigger_r = batch_recall(trigger_pred, trigger_labels)
            trigger_f = batch_f1(trigger_pred, trigger_labels)
            idification_trigger_p = idification_precision(trigger_pred, trigger_labels)
            idification_trigger_r = idification_recall(trigger_pred, trigger_labels)
            idification_trigger_f = idification_f1(trigger_pred, trigger_labels)

            ta_p = batch_precision(ta_pred, trigger_argument_labels)
            ta_r = batch_recall(ta_pred, trigger_argument_labels)
            ta_f = batch_f1(ta_pred, trigger_argument_labels)
            idification_ta_p = idification_precision(ta_pred, trigger_argument_labels)
            idification_ta_r = idification_recall(ta_pred, trigger_argument_labels)
            idification_ta_f = idification_f1(ta_pred, trigger_argument_labels)

            aa_p = batch_precision(aa_pred, argument_argument_labels)
            aa_r = batch_recall(aa_pred, argument_argument_labels)
            aa_f = batch_f1(aa_pred, argument_argument_labels)
            idification_aa_p = idification_precision(aa_pred, argument_argument_labels)
            idification_aa_r = idification_recall(aa_pred, argument_argument_labels)
            idification_aa_f = idification_f1(aa_pred, argument_argument_labels)

            self.train_metrics.update('idification_trigger_p', idification_trigger_p)
            self.train_metrics.update('idification_trigger_r', idification_trigger_r)
            self.train_metrics.update('idification_trigger_f', idification_trigger_f)
            self.train_metrics.update('trigger_p', trigger_p)
            self.train_metrics.update('trigger_r', trigger_r)
            self.train_metrics.update('trigger_f', trigger_f)

            self.train_metrics.update('idification_ta_p', idification_ta_p)
            self.train_metrics.update('idification_ta_r', idification_ta_r)
            self.train_metrics.update('idification_ta_f', idification_ta_f)
            self.train_metrics.update('ta_p', ta_p)
            self.train_metrics.update('ta_r', ta_r)
            self.train_metrics.update('ta_f', ta_f)

            self.train_metrics.update('idification_aa_p', idification_aa_p)
            self.train_metrics.update('idification_aa_r', idification_aa_r)
            self.train_metrics.update('idification_aa_f', idification_aa_f)
            self.train_metrics.update('aa_p', aa_p)
            self.train_metrics.update('aa_r', aa_r)
            self.train_metrics.update('aa_f', aa_f)

            if batch_idx % self.log_step == 0:
                self.logger.debug('Train Epoch: {} {} Loss: {:.6f}'.format(
                    epoch,
                    self._progress(batch_idx),
                    total_loss.item()))

            if batch_idx == self.len_epoch:
                break

        log = self.train_metrics.result()

        if self.do_validation:
            val_log = self._valid_epoch(epoch)
            log.update(**{'val_' + k: v for k, v in val_log.items()})

        if self.lr_scheduler is not None:
            self.lr_scheduler.step()
        print('spending time:', time() - t1)
        return log

    def _valid_epoch(self, epoch):
        """
        Validate after training an epoch

        :param epoch: Integer, current training epoch.
        :return: A log that contains information about validation
        """
        self.model.eval()
        self.valid_metrics.reset()

        with torch.no_grad():
            for batch_idx, batch_data in enumerate(self.valid_iter):
                input_ids, attention_masks, text_lengths, candidate_arguments, \
                candidate_argument_types, candidate_argument_arcs, candidate_argument_relateds, \
                candidate_triggers, candidate_trigger_arcs, candidate_trigger_relateds, \
                trigger_labels, trigger_argument_labels, argument_argument_labels = batch_data

                if 'cuda' == self.device.type:
                    input_ids = input_ids.cuda()
                    attention_masks = attention_masks.cuda()
                    text_lengths = text_lengths.cuda()

                    candidate_arguments = candidate_arguments.cuda()
                    candidate_argument_types = candidate_argument_types.cuda()
                    candidate_argument_arcs = candidate_argument_arcs.cuda()
                    candidate_argument_relateds = candidate_argument_relateds.cuda()

                    candidate_triggers = candidate_triggers.cuda()
                    candidate_trigger_arcs = candidate_trigger_arcs.cuda()
                    candidate_trigger_relateds = candidate_trigger_relateds.cuda()

                    trigger_labels = trigger_labels.cuda()
                    trigger_argument_labels = trigger_argument_labels.cuda()
                    argument_argument_labels = argument_argument_labels.cuda()

                trigger_pred, ta_pred, aa_pred = self.model(input_ids,
                                                            text_lengths,
                                                            attention_masks,
                                                            candidate_triggers,
                                                            candidate_arguments,
                                                            candidate_argument_types,
                                                            candidate_trigger_arcs,
                                                            candidate_trigger_relateds,
                                                            candidate_argument_arcs,
                                                            candidate_argument_relateds
                                                            )
                trigger_loss = self.criterion[0](trigger_pred, trigger_labels)
                trigger_argument_loss = self.criterion[1](ta_pred, trigger_argument_labels)
                argument_argument_loss = self.criterion[1](aa_pred, argument_argument_labels)
                total_loss = trigger_loss + trigger_argument_loss + argument_argument_loss
                # get_trigger_text(trigger_labels,texts)

                trigger_acc = self.metric_ftns[0](trigger_pred, trigger_labels)
                ta_acc = self.metric_ftns[0](ta_pred, trigger_argument_labels)
                aa_acc = self.metric_ftns[0](aa_pred, argument_argument_labels)

                self.writer.set_step((epoch - 1) * len(self.valid_iter) + batch_idx, 'valid')
                self.valid_metrics.update('trigger_loss', trigger_loss.item())
                self.valid_metrics.update('trigger_argument_loss', trigger_argument_loss.item())
                self.valid_metrics.update('argument_argument_loss', argument_argument_loss.item())
                self.valid_metrics.update('total_loss', total_loss.item())
                self.valid_metrics.update('trigger_acc', trigger_acc)
                self.valid_metrics.update('trigger_argument_acc', ta_acc)
                self.valid_metrics.update('argument_argument_acc', aa_acc)

                trigger_p = batch_precision(trigger_pred, trigger_labels)
                trigger_r = batch_recall(trigger_pred, trigger_labels)
                trigger_f = batch_f1(trigger_pred, trigger_labels)
                idification_trigger_p = idification_precision(trigger_pred, trigger_labels)
                idification_trigger_r = idification_recall(trigger_pred, trigger_labels)
                idification_trigger_f = idification_f1(trigger_pred, trigger_labels)

                ta_p = batch_precision(ta_pred, trigger_argument_labels)
                ta_r = batch_recall(ta_pred, trigger_argument_labels)
                ta_f = batch_f1(ta_pred, trigger_argument_labels)
                idification_ta_p = idification_precision(ta_pred, trigger_argument_labels)
                idification_ta_r = idification_recall(ta_pred, trigger_argument_labels)
                idification_ta_f = idification_f1(ta_pred, trigger_argument_labels)

                aa_p = batch_precision(aa_pred, argument_argument_labels)
                aa_r = batch_recall(aa_pred, argument_argument_labels)
                aa_f = batch_f1(aa_pred, argument_argument_labels)
                idification_aa_p = idification_precision(aa_pred, argument_argument_labels)
                idification_aa_r = idification_recall(aa_pred, argument_argument_labels)
                idification_aa_f = idification_f1(aa_pred, argument_argument_labels)

                self.valid_metrics.update('idification_trigger_p', idification_trigger_p)
                self.valid_metrics.update('idification_trigger_r', idification_trigger_r)
                self.valid_metrics.update('idification_trigger_f', idification_trigger_f)
                self.valid_metrics.update('trigger_p', trigger_p)
                self.valid_metrics.update('trigger_r', trigger_r)
                self.valid_metrics.update('trigger_f', trigger_f)

                self.valid_metrics.update('idification_ta_p', idification_ta_p)
                self.valid_metrics.update('idification_ta_r', idification_ta_r)
                self.valid_metrics.update('idification_ta_f', idification_ta_f)
                self.valid_metrics.update('ta_p', ta_p)
                self.valid_metrics.update('ta_r', ta_r)
                self.valid_metrics.update('ta_f', ta_f)

                self.valid_metrics.update('idification_aa_p', idification_aa_p)
                self.valid_metrics.update('idification_aa_r', idification_aa_r)
                self.valid_metrics.update('idification_aa_f', idification_aa_f)
                self.valid_metrics.update('aa_p', aa_p)
                self.valid_metrics.update('aa_r', aa_r)
                self.valid_metrics.update('aa_f', aa_f)

        # add histogram of model parameters to the tensorboard
        for name, p in self.model.named_parameters():
            self.writer.add_histogram(name, p, bins='auto')
        return self.valid_metrics.result()

    def _progress(self, batch_idx):
        base = '[{}/{} ({:.0f}%)]'
        if hasattr(self.train_iter, 'n_samples'):
            current = batch_idx * self.data_loader.batch_size
            total = self.data_loader.n_samples
        else:
            current = batch_idx
            total = self.len_epoch
        return base.format(current, total, 100.0 * current / total)
