
from model.metric import categorical_accuracy
from utils import inf_loop, MetricTracker, updata_metrics_log
from base import BaseTrainer
import torch
import numpy as np
from torch.utils.data import DataLoader
import utils.query_strategies as module_query_strategies
import transformers
from utils import LossPredLoss


class Trainer(BaseTrainer):
    """
    Trainer class
    """

    def __init__(self, model, criterion, metric_ftns, optimizer, config, train_dataset,
                 valid_dataset=None, query_dataset=None, test_dataset=None, lr_scheduler=None, len_epoch=None):
        super().__init__(model, criterion, metric_ftns, optimizer, config)
        self.config = config
        data_loader = DataLoader(train_dataset, batch_size=train_dataset.batch_size,drop_last=True,
                                 num_workers=train_dataset.num_workers, collate_fn=train_dataset.collate_fn)
        self.train_dataset = train_dataset
        self.query_pool = query_dataset
        self.idxs_labeled = np.zeros(len(query_dataset), dtype=bool)  # 用于记录查询集中被标记过的样本
        self.data_loader = data_loader
        if len_epoch is None:
            # epoch-based training
            self.len_epoch = len(self.data_loader)
        else:
            # iteration-based training
            self.data_loader = inf_loop(data_loader)
            self.len_epoch = len_epoch

        self.valid_data_loader = None
        self.test_data_loader = None
        self.lr_scheduler = lr_scheduler
        if valid_dataset:
            self.valid_data_loader = DataLoader(valid_dataset, batch_size=valid_dataset.batch_size,drop_last=True,
                                                num_workers=valid_dataset.num_workers,
                                                collate_fn=valid_dataset.collate_fn)
        if test_dataset:
            self.test_data_loader = DataLoader(test_dataset, batch_size=test_dataset.batch_size,
                                               num_workers=test_dataset.num_workers, collate_fn=test_dataset.collate_fn)

        self.log_step = int(np.sqrt(data_loader.batch_size))

        self.train_metrics = MetricTracker(
                                           'total_loss',
                                           'trigger_f',
                                            'ta_f',
                                           writer=self.writer)

        self.valid_metrics = MetricTracker(
                                           'total_loss',
                                            'trigger_f',
                                            'ta_f',
                                           writer=self.writer)

        self.test_metrics = MetricTracker('loss', *[m.__name__ for m in self.metric_ftns], writer=self.writer)
        torch.cuda.set_device(self.device)

    def _train_epoch(self, epoch):
        """
        """
        self.model.train()
        self.train_metrics.reset()
        data_iter = iter(self.data_loader)
        self._save_checkpoint()
        self.train_embeddings = []
        batch_idx = 0
        while True:
            try:
                data = next(data_iter)
            except StopIteration:
                break

            self.optimizer.zero_grad()
            input_ids, attention_masks, text_lengths, candidate_arguments, \
            candidate_argument_types, candidate_argument_arcs, candidate_argument_relateds, \
            candidate_triggers, candidate_trigger_arcs, candidate_trigger_relateds, \
            trigger_labels, trigger_argument_labels, argument_argument_labels, trigger_nums, argument_nums = data

            if 'cuda' == self.device.type:
                input_ids = input_ids.to(self.device)
                attention_masks = attention_masks.to(self.device)
                text_lengths = text_lengths.to(self.device)

                candidate_arguments = candidate_arguments.to(self.device)
                candidate_argument_types = candidate_argument_types.to(self.device)
                candidate_argument_arcs = candidate_argument_arcs.to(self.device)
                candidate_argument_relateds = candidate_argument_relateds.to(self.device)

                candidate_triggers = candidate_triggers.to(self.device)
                candidate_trigger_arcs = candidate_trigger_arcs.to(self.device)
                candidate_trigger_relateds = candidate_trigger_relateds.to(self.device)

                trigger_labels = trigger_labels.to(self.device)
                trigger_argument_labels = trigger_argument_labels.to(self.device)


            trigger_pred, ta_pred,cls_embedding,pred_loss = self.model(input_ids,
                                                        text_lengths,
                                                        attention_masks,
                                                        candidate_triggers,
                                                        candidate_arguments,
                                                        candidate_argument_types,
                                                        candidate_trigger_arcs,
                                                        candidate_trigger_relateds,
                                                        candidate_argument_arcs,
                                                        candidate_argument_relateds
                                                        )
            self.t_entropy_weight_ = torch.ones(int(self.config.config['model_arch']['args']['event_num'])).to(self.device)
            self.t_entropy_weight_[0] = 0.1
            self.ta_entropy_weight_ = torch.ones(int(self.config.config['model_arch']['args']['role_num'])).to(self.device)
            self.ta_entropy_weight_[0] = 0.1
            self.train_embeddings.append(cls_embedding)

            if 'loss' in self.config.config['active_learning']['type']:
                trigger_loss = self.criterion[0](trigger_pred, trigger_labels, reduction='none',
                                                 weight=self.t_entropy_weight_)
                trigger_argument_loss = self.criterion[1](ta_pred, trigger_argument_labels, reduction='none',
                                                          weight=self.ta_entropy_weight_)

                trigger_loss = torch.mean(trigger_loss, dim=-1)
                ta_loss = torch.mean(trigger_argument_loss, dim=-1)
                ta_loss = torch.mean(ta_loss, dim=-1)
                target_loss = trigger_loss + ta_loss
                module_loss = LossPredLoss(pred_loss, target_loss)
                total_loss = target_loss.mean() + module_loss * 0.001
            else:
                trigger_loss = self.criterion[0](trigger_pred, trigger_labels, reduction='mean',
                                                 weight=self.t_entropy_weight_)
                trigger_argument_loss = self.criterion[1](ta_pred, trigger_argument_labels, reduction='mean',
                                                          weight=self.ta_entropy_weight_)

                total_loss = trigger_loss + trigger_argument_loss
            total_loss.backward()

            self.optimizer.step()
            self.writer.set_step((epoch - 1) * self.len_epoch + batch_idx)

            # loss
            # self.train_metrics.update('trigger_loss', trigger_loss.item())
            # self.train_metrics.update('trigger_argument_loss', trigger_argument_loss.item())
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), 1)
            self.model.zero_grad()
            self.train_metrics.update('total_loss', total_loss.item())
            updata_metrics_log(self.train_metrics, trigger_pred, trigger_labels, ta_pred,
                               trigger_argument_labels)

            if batch_idx % self.log_step == 0:
                self.logger.debug('Train Epoch: {} {} Loss: {:.3f}'.format(epoch, self._progress(batch_idx),
                                                                           total_loss.item()))

            if batch_idx == self.len_epoch:
                break
            batch_idx += 1
        log = self.train_metrics.result()
        # self.lr_scheduler.step()
        if self.valid_data_loader:
            val_log = self._valid_epoch(epoch)
            log.update(**{'val_' + k: v for k, v in val_log.items()})

        if self.not_improved_count >= self.early_stop:  
            log.update({
                'num sample in train set': len(self.train_dataset),
                'num sample in query pool': np.sum(~self.idxs_labeled)
            })
            for key, value in log.items():
                self.logger.info('    {:30s}: {}'.format(str(key), value))
            self.logger.info("Validation performance didn\'t improve for {} epochs. "
                             "Training stops.sampling query pool ...".format(self.early_stop))


            self._query_epoch()
            self.len_epoch = len(self.data_loader)
            self.not_improved_count = 0

        log.update({
            'num sample in train set': len(self.train_dataset),
            'num sample in query pool': np.sum(~self.idxs_labeled)
        })

        return log

    def _valid_epoch(self, epoch):
        """
        """
        self.model.eval()
        self.valid_metrics.reset()
        with torch.no_grad():
            for batch_idx, data in enumerate(self.valid_data_loader):
                input_ids, attention_masks, text_lengths, candidate_arguments, \
                candidate_argument_types, candidate_argument_arcs, candidate_argument_relateds, \
                candidate_triggers, candidate_trigger_arcs, candidate_trigger_relateds, \
                trigger_labels, trigger_argument_labels, argument_argument_labels, trigger_nums, argument_nums = data

                if 'cuda' == self.device.type:
                    input_ids = input_ids.cuda(self.device)
                    attention_masks = attention_masks.cuda(self.device)
                    text_lengths = text_lengths.cuda(self.device)

                    candidate_arguments = candidate_arguments.cuda(self.device)
                    candidate_argument_types = candidate_argument_types.cuda(self.device)
                    candidate_argument_arcs = candidate_argument_arcs.cuda(self.device)
                    candidate_argument_relateds = candidate_argument_relateds.cuda(self.device)

                    candidate_triggers = candidate_triggers.cuda(self.device)
                    candidate_trigger_arcs = candidate_trigger_arcs.cuda(self.device)
                    candidate_trigger_relateds = candidate_trigger_relateds.cuda(self.device)

                    trigger_labels = trigger_labels.cuda(self.device)
                    trigger_argument_labels = trigger_argument_labels.cuda(self.device)

                trigger_pred, ta_pred,cls_embedding,pred_loss = self.model(input_ids,
                                                            text_lengths,
                                                            attention_masks,
                                                            candidate_triggers,
                                                            candidate_arguments,
                                                            candidate_argument_types,
                                                            candidate_trigger_arcs,
                                                            candidate_trigger_relateds,
                                                            candidate_argument_arcs,
                                                            candidate_argument_relateds
                                                            )



                if 'loss' in self.config.config['active_learning']['type']:
                    trigger_loss = self.criterion[0](trigger_pred, trigger_labels, reduction='none',
                                                     weight=self.t_entropy_weight_)
                    trigger_argument_loss = self.criterion[1](ta_pred, trigger_argument_labels, reduction='none',
                                                              weight=self.ta_entropy_weight_)

                    trigger_loss = torch.mean(trigger_loss, dim=-1)
                    ta_loss = torch.mean(trigger_argument_loss, dim=-1)
                    ta_loss = torch.mean(ta_loss, dim=-1)
                    target_loss = trigger_loss + ta_loss
                    module_loss = LossPredLoss(pred_loss, target_loss)
                    total_loss = target_loss.mean() + module_loss * 0.001
                else:
                    trigger_loss = self.criterion[0](trigger_pred, trigger_labels, reduction='mean',
                                                     weight=self.t_entropy_weight_)
                    trigger_argument_loss = self.criterion[1](ta_pred, trigger_argument_labels, reduction='mean',
                                                              weight=self.ta_entropy_weight_)


                    total_loss = trigger_loss + trigger_argument_loss

                self.writer.set_step((epoch - 1) * len(self.valid_data_loader) + batch_idx, 'valid')
                self.valid_metrics.update('total_loss', total_loss.item())
                updata_metrics_log(self.valid_metrics, trigger_pred, trigger_labels, ta_pred,
                                   trigger_argument_labels)

        return self.valid_metrics.result()

    def _query_epoch(self):

        query_labeled = self._query()
        # self._query_train()
        sample_labeled = np.asarray(self.query_pool)[query_labeled]
        self.train_dataset.features.extend(sample_labeled)
        self.data_loader = DataLoader(self.train_dataset, batch_size=self.train_dataset.batch_size,drop_last=True,

                                      num_workers=self.train_dataset.num_workers, shuffle=True,
                                      collate_fn=self.train_dataset.collate_fn)
        self.makeLrSchedule()


    def _query(self):
        """
        :return:
        """
        query_num = self.config['active_learning']['query_num']  
        if not isinstance(query_num, int):
            query_num = len(self.query_pool)

        idxs_unlabeled = np.arange(len(self.query_pool))[~self.idxs_labeled]  
        unlabeled_dataloader = DataLoader(np.array(self.query_pool)[idxs_unlabeled],
                                          batch_size=self.query_pool.batch_size,drop_last=True,
                                          shuffle=False,
                                          num_workers=self.query_pool.num_workers,
                                          collate_fn=self.query_pool.collate_fn)
        indexes = []
        trigger_preds = []
        ta_preds = []
        pred_losses = []

        # load best model for query
        self._resume_checkpoint(self.best_path)
        self.query_embeddings = []
        self.model.eval()
        with torch.no_grad():
            for batch_idx, data in enumerate(unlabeled_dataloader):
                if batch_idx * self.query_pool.batch_size >= query_num:
                    break
                input_ids, attention_masks, text_lengths, candidate_arguments, \
                candidate_argument_types, candidate_argument_arcs, candidate_argument_relateds, \
                candidate_triggers, candidate_trigger_arcs, candidate_trigger_relateds, \
                trigger_labels, trigger_argument_labels, argument_argument_labels, trigger_nums, argument_nums = data

                if 'cuda' == self.device.type:
                    input_ids = input_ids.cuda(self.device)
                    attention_masks = attention_masks.cuda(self.device)
                    text_lengths = text_lengths.cuda(self.device)

                    candidate_arguments = candidate_arguments.cuda(self.device)
                    candidate_argument_types = candidate_argument_types.cuda(self.device)
                    candidate_argument_arcs = candidate_argument_arcs.cuda(self.device)
                    candidate_argument_relateds = candidate_argument_relateds.cuda(self.device)

                    candidate_triggers = candidate_triggers.cuda(self.device)
                    candidate_trigger_arcs = candidate_trigger_arcs.cuda(self.device)
                    candidate_trigger_relateds = candidate_trigger_relateds.cuda(self.device)

                trigger_pred, ta_pred,cls_embedding,pred_loss = self.model(input_ids, text_lengths, attention_masks,
                                                            candidate_triggers,
                                                            candidate_arguments, candidate_argument_types,
                                                            candidate_trigger_arcs,
                                                            candidate_trigger_relateds, candidate_argument_arcs,
                                                            candidate_argument_relateds)

                indexes.extend(list(idxs_unlabeled[batch_idx * self.query_pool.batch_size:(
                                                                                                  batch_idx + 1) * self.query_pool.batch_size]))

                for i in range(len(trigger_pred)):
                    trigger_prob = torch.softmax(trigger_pred[i][:trigger_nums[i]],dim=-1)
                    trigger_ent = torch.sum(-trigger_prob * torch.log2(trigger_prob),dim=-1)
                    trigger_preds.append(torch.mean(trigger_ent))

                    ta_prob = torch.softmax(ta_pred[i][:trigger_nums[i]][:argument_nums[i]],dim=-1)
                    ta_ent = torch.mean(torch.sum(-ta_prob * torch.log2(ta_prob),dim=-1))
                    ta_preds.append(ta_ent)

                self.query_embeddings.append(cls_embedding)
                pred_losses.append(pred_loss)

        indexes = np.asarray(indexes)

        query_labeled = self.config.init_ftn('active_learning', module_query_strategies)(
            logists=[trigger_preds, ta_preds,pred_losses],
            embeddings=(self.train_embeddings,self.query_embeddings),
            idxs_unlabeled=indexes)
        self.idxs_labeled[query_labeled] = True
        return query_labeled

    def _progress(self, batch_idx):
        base = '[{}/{} ({:.0f}%)]'
        if hasattr(self.data_loader, 'n_samples'):
            current = batch_idx * self.data_loader.batch_size
            total = self.data_loader.n_samples
        else:
            current = batch_idx
            total = self.len_epoch
        return base.format(current, total, 100.0 * current / total)

    def makeLrSchedule(self):
        self.lr_scheduler = self.config.init_obj('lr_scheduler', transformers.optimization, self.optimizer,
                                                 num_training_steps=int(
                                                     len(self.train_dataset) / self.train_dataset.batch_size))
