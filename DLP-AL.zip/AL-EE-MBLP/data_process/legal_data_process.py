

from base import BaseDataSet
from pathlib import Path
from typing import List, Optional, Union, Dict
from dataclasses import dataclass
import torch
import json
import numpy as np
from tqdm import tqdm
from utils import get_trigger_candidate_index, get_candidate_argument, get_parse_arces, init_pyltp \
    , align_text_seg, get_arc_matrix, entity_map_id, get_candidate_arguments, get_trigger_gold, get_candidate_triggers, \
    get_arc_related, get_argument_argument_label

class LegalSchema:
    def __init__(self):
        self.entity_type_2_id = {'O': 0, '人身状态': 1, '时间': 2, '地点': 3, '犯罪属性（影响\\手段\\事由\\时态）': 4, '物品': 5,
                                 '行为': 6, '物品属性（价值）': 7, '驾驶状态': 8, '当事人属性': 9, '罪名': 10, '物品属性': 11,
                                 '犯罪属性': 12, '法律条款': 13, '惩罚 / 强制 - 属性': 14, '政府机关': 15, '当事人': 16,
                                 '交通肇事事件': 17, '抢劫事件': 18, '故意杀人事件': 19, '诈骗事件': 20, '危险驾驶事件': 21, '审判事件': 22,
                                 '拘留事件': 23, '逮捕事件': 24, '保释事件': 25, '盗窃事件': 26, '故意伤害事件': 27
                                 }
        self.id_2_entity_type = {
            0: 'O', 1: '人身状态', 2: '时间', 3: '地点', 4: '犯罪属性（影响\\手段\\事由\\时态）', 5: '物品',
            6: '行为', 7: '物品属性（价值）', 8: '驾驶状态', 9: '当事人属性', 10: '罪名', 11: '物品属性',
            12: '犯罪属性', 13: '法律条款', 14: '惩罚 / 强制 - 属性', 15: '政府机关', 16: '当事人',
            17: '交通肇事事件', 18: '抢劫事件', 19: '故意杀人事件', 20: '诈骗事件', 21: '危险驾驶事件', 22: '审判事件',
            23: '拘留事件', 24: '逮捕事件', 25: '保释事件', 26: '盗窃事件', 27: '故意伤害事件'
        }

        self.event_type_2_id = {'O': 0, '交通肇事事件': 1, '抢劫事件': 2, '故意杀人事件': 3, '诈骗事件': 4, '危险驾驶事件': 5, '审判事件': 6,
                                '拘留事件': 7, '逮捕事件': 8, '保释事件': 9, '盗窃事件': 10, '故意伤害事件': 11}
        self.id_2_event_type = {
            0: 'O', 1: '交通肇事事件', 2: '抢劫事件', 3: '故意杀人事件', 4: '诈骗事件', 5: '危险驾驶事件', 6: '审判事件',
            7: '拘留事件', 8: '逮捕事件', 9: '保释事件', 10: '盗窃事件', 11: '故意伤害事件'
        }

        self.role_type_2_id = {'O': 0, '被告人': 1, '犯罪地点': 2, '事由': 3, '作案工具': 4, '受害人': 5, '财物': 6,
                               '时态': 7, '危险驾驶状态': 8, '罪名': 9, '法条依据': 10, '惩罚/强制行为': 11, '影响': 12,
                               '手段（残忍）': 13, '犯罪时态': 14, '执法机关': 15, '羁押时间': 16, '指控罪名': 17, '逮捕时间': 18, '起诉机关': 19,
                               '羁押地点': 20, '保释时间': 21, '犯罪时间': 22, '手段': 23}

        self.id_2_role_type = {0: 'O', 1: '被告人', 2: '犯罪地点', 3: '事由', 4: '作案工具', 5: '受害人', 6: '财物',
                               7: '时态', 8: '危险驾驶状态', 9: '罪名', 10: '法条依据', 11: '惩罚/强制行为', 12: '影响',
                               13: '手段（残忍）', 14: '犯罪时态', 15: '执法机关', 16: '羁押时间', 17: '指控罪名', 18: '逮捕时间', 19: '起诉机关',
                               20: '羁押地点', 21: '保释时间', 22: '犯罪时间', 23: '手段'}

        self.relation_type_2_id = {'O': 0, '犯后行为': 1, '价值': 2, '年龄': 3, '前科': 4, '犯前行为': 5, '精神状态': 6, '主观意愿': 7,
                                   '态度': 8, '涉及物品': 9, '犯罪行为': 10, '伤情': 11, '缓刑期限': 12, '刑期(包含其他强制行为的期限)': 13,
                                   '罚金': 14, '民族': 15, '出生时间': 16, '伤残情况': 17}

        self.id_2_relation_type = {0: 'O', 1: '犯后行为', 2: '价值', 3: '年龄', 4: '前科', 5: '犯前行为', 6: '精神状态', 7: '主观意愿',
                                   8: '态度', 9: '涉及物品', 10: '犯罪行为', 11: '伤情', 12: '缓刑期限', 13: '刑期(包含其他强制行为的期限)',
                                   14: '罚金', 15: '民族', 16: '出生时间', 17: '伤残情况'}

        self.arc_type_id = {'O': 0, 'ATT': 1, 'ADV': 2, 'RAD': 3, 'WP': 4, 'SBV': 5, 'VOB': 6, 'HED': 7, 'COO': 8,
                            'CMP': 9,'POB': 10, 'LAD': 11, 'DBL': 12, 'FOB': 13, 'IOB': 14}

@dataclass
class InputExample:
    """
    """

    guid: Optional[str]
    text: str
    entities: Dict
    relations: Dict
    events: Dict
    text_tokenized: List[str]
    postaggers: List[str]
    arces: List[str]

    def __post_init__(self):
        self.sent_len = len(self.text) + 2
        self.text_map_seg, self.seg_map_text = align_text_seg(self.text_tokenized)


@dataclass
class InputFeatures:
    """
    """
    guid: Optional[str]
    input_ids: List[int]
    attention_mask: List[int]
    entity_id_2_id: Dict

    candidate_arguments: List  
    candidate_argument_type: List  
    argument_arc: List  
    argument_arc_related: List  
    argument_max_num_arc: int 

    candidate_triggers: List  

    trigger_arc: List  
    trigger_arc_related: List  
    trigger_max_num_arc: int  
    trigger_label: List  
    triggers_arguments_label: List  
    argument_argument_label: List 



    def __post_init__(self):
        self.sent_len = len(self.input_ids)
        self.trigger_num = len(self.trigger_label)
        self.argument_num = len(self.triggers_arguments_label)



class LegalDataset(BaseDataSet):
    def __init__(self, data_dir, ltp_dir, file_name, shuffle, transformer_model, overwrite_cache, force_download,
                 cache_dir, batch_size, num_workers):

        self.shuffle = shuffle
        self.data_dir = Path(data_dir)
        self.postagger, self.parser, self.seg = init_pyltp(ltp_dir=ltp_dir)
        self.file_name = file_name
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.schema = LegalSchema()
        
        self.feature_cache_file = self.data_dir / '.cache' / '{}.cache'.format(file_name.split('.')[0])
        super(LegalDataset, self).__init__(transformer_model=transformer_model, overwrite_cache=overwrite_cache,
                                           force_download=force_download, cache_dir=cache_dir)

    def read_examples_from_file(self):
        input_file = self.data_dir / self.file_name
        with input_file.open('r') as f:
            for line in tqdm(f):
                json_line = json.loads(line)
                text = json_line['text'][:510]
                text_tokenized = list(self.seg.segment(text))
                postaggers = self.postagger.postag(text_tokenized)
                arces = get_parse_arces(text_tokenized, self.postagger, self.parser)

                yield InputExample(guid=json_line['id'], text=text, entities=json_line['entities'],
                                   relations=json_line['relations'], events=json_line['events'],
                                   text_tokenized=text_tokenized, postaggers=postaggers, arces=arces)

    def convert_examples_to_features(self):
        features = []
        for example in self.read_examples_from_file():
            inputs = self.tokenizer.encode_plus(list(example.text), add_special_tokens=True, return_attention_mask=True)
            candidate_trigger_idxs = get_trigger_candidate_index(example.postaggers)
            gold_trigger_entities = get_trigger_gold(example.events)

            candidate_arguments_entities = get_candidate_argument(example.entities)
            arc_matrix = get_arc_matrix(example.sent_len, example.seg_map_text, example.arces, self.schema.arc_type_id)

            entity_id_2_id = entity_map_id(example.entities)

            candidate_arguments, candidate_argument_range, candidate_argument_type = \
                get_candidate_arguments(example.sent_len, self.schema.entity_type_2_id, candidate_arguments_entities)

            candidate_triggers, candidate_trigger_ranges, trigger_label, triggers_arguments_label = \
                get_candidate_triggers(example.sent_len, entity_id_2_id, self.schema, example.seg_map_text,
                                       candidate_trigger_idxs, gold_trigger_entities,
                                       example.events)

            trigger_arc, trigger_arc_related, trigger_max_num_arc = get_arc_related(example.sent_len,
                                                                                    example.text_map_seg,
                                                                                    example.seg_map_text,
                                                                                    candidate_triggers,
                                                                                    candidate_trigger_ranges,
                                                                                    arc_matrix)

            argument_arc, argument_arc_related, argument_max_num_arc = get_arc_related(example.sent_len,
                                                                                       example.text_map_seg,
                                                                                       example.seg_map_text,
                                                                                       candidate_arguments,
                                                                                       candidate_argument_range,
                                                                                       arc_matrix)

            argument_argument_label = get_argument_argument_label(example.relations, entity_id_2_id, self.schema)
            assert len(inputs.data['input_ids']) == example.sent_len, 'sent len is not equal'
            features.append(InputFeatures(guid=example.guid, input_ids=inputs.data['input_ids'],
                                          attention_mask=inputs.data['attention_mask'], entity_id_2_id=entity_id_2_id,
                                          candidate_arguments=candidate_arguments,
                                          candidate_argument_type=candidate_argument_type,
                                          argument_arc=argument_arc, argument_arc_related=argument_arc_related,
                                          argument_max_num_arc=argument_max_num_arc,
                                          candidate_triggers=candidate_triggers, trigger_arc=trigger_arc,
                                          trigger_arc_related=trigger_arc_related,
                                          trigger_max_num_arc=trigger_max_num_arc, trigger_label=trigger_label,
                                          triggers_arguments_label=triggers_arguments_label,
                                          argument_argument_label=argument_argument_label))
        return features

    def collate_fn(self, datas: List[InputFeatures]):

        max_seq_len = max([data.sent_len for data in datas]) 
        K = max([len(data.candidate_triggers) for data in datas])  
        m = max([len(data.entity_id_2_id) for data in datas]) 
        trigger_e = max([data.trigger_max_num_arc for data in datas])  
        argument_e = max([data.argument_max_num_arc for data in datas])  

        input_ids = []
        attention_masks = []
        text_lengths = []

        candidate_arguments = []
        candidate_argument_types = []
        candidate_argument_arcs = []
        candidate_argument_relateds = []

        candidate_triggers = []
        candidate_trigger_arcs = []
        candidate_trigger_relateds = []

        trigger_labels = []
        trigger_argument_labels = []
        argument_argument_labels = []

        trigger_nums = []
        argument_nums = []

        for data in datas:
            text_lengths.append(data.sent_len)
            input_ids.append(data.input_ids + [self.tokenizer.pad_token_id] * (max_seq_len - data.sent_len))
            attention_masks.append((data.attention_mask + [0] * (max_seq_len - data.sent_len)))

            candidate_argument = np.zeros((m, max_seq_len))
            candidate_argument[:len(data.candidate_arguments), :data.sent_len] = np.array(data.candidate_arguments)
            candidate_arguments.append(candidate_argument)
            candidate_argument_types.append(
                data.candidate_argument_type + [0] * (m - len(data.candidate_argument_type)))

            argument_arcs_tensors = []
            argument_arc_related = []  
            for idx, arcs in enumerate(data.argument_arc):
                arcs_tensor = np.zeros(argument_e)
                arcs_tensor[:len(arcs)] = np.array(arcs)
                argument_arcs_tensors.append(arcs_tensor)  

                related_entities = np.zeros((argument_e, max_seq_len))  
                if len(arcs) > 0:
                    related_entities[:len(arcs), :data.sent_len] = np.array(data.argument_arc_related[idx])
                argument_arc_related.append(related_entities)

            candidate_argument_arc = np.zeros((m, argument_e))  
            candidate_argument_arc[:len(argument_arcs_tensors)] = np.array(argument_arcs_tensors)
            candidate_argument_arcs.append(candidate_argument_arc)

            candidate_argument_related = np.zeros((m, argument_e, max_seq_len))
            candidate_argument_related[:len(argument_arcs_tensors), :, :] = np.array(argument_arc_related)
            candidate_argument_relateds.append(candidate_argument_related)

            candidate_trigger = np.zeros((K, max_seq_len))
            candidate_trigger[:len(data.candidate_triggers), :data.sent_len] = np.array(data.candidate_triggers)
            candidate_triggers.append(candidate_trigger)

            arcs_tensors = []
            related = []
            for idx, arcs in enumerate(data.trigger_arc):
               
                arcs_tensor = np.zeros(data.trigger_max_num_arc)
                arcs_tensor[:len(arcs)] = np.array(arcs)
                arcs_tensors.append(arcs_tensor)

                related_entities = np.zeros((trigger_e, max_seq_len))
                if len(arcs) > 0:
                    related_entities[:len(arcs), :data.sent_len] = np.array(data.trigger_arc_related[idx])
                related.append(related_entities)

            candidate_trigger_arc = np.zeros((K, trigger_e))
            candidate_trigger_arc[:len(arcs_tensors), :data.trigger_max_num_arc] = np.array(arcs_tensors)
            candidate_trigger_arcs.append(candidate_trigger_arc)

            candidate_trigger_related = np.zeros((K, trigger_e, max_seq_len))
            candidate_trigger_related[:len(arcs_tensors), :, :max_seq_len] = np.array(related)
            candidate_trigger_relateds.append(candidate_trigger_related)

            trigger_labels.append(data.trigger_label + [0] * (K - len(data.trigger_label)))

            # trigger_argument_label [B,K,M]
            trigger_argument_label = np.zeros((K, m))
            trigger_argument_label[:len(data.trigger_label), :(len(data.candidate_arguments))] =\
                np.array(data.triggers_arguments_label)
            trigger_argument_labels.append(trigger_argument_label)

            # argument_argument_label [B,M,M]
            argument_argument_label = np.zeros((m, m))
            argument_argument_label[:(len(data.entity_id_2_id)),
            :(len(data.entity_id_2_id))] = data.argument_argument_label
            argument_argument_labels.append(argument_argument_label)

            trigger_nums.append(data.trigger_num)
            argument_nums.append(data.argument_num)

        input_ids = torch.LongTensor(input_ids)
        attention_masks = torch.LongTensor(attention_masks)
        text_lengths = torch.LongTensor(text_lengths)

        candidate_arguments = torch.FloatTensor(candidate_arguments)
        candidate_argument_types = torch.LongTensor(candidate_argument_types)
        candidate_argument_arcs = torch.LongTensor(candidate_argument_arcs)
        candidate_argument_relateds = torch.FloatTensor(candidate_argument_relateds)

        candidate_triggers = torch.FloatTensor(candidate_triggers)
        candidate_trigger_arcs = torch.LongTensor(candidate_trigger_arcs)
        candidate_trigger_relateds = torch.FloatTensor(candidate_trigger_relateds)

        trigger_labels = torch.LongTensor(trigger_labels)
        trigger_argument_labels = torch.LongTensor(trigger_argument_labels)
        argument_argument_labels = torch.LongTensor(argument_argument_labels)

        return input_ids,attention_masks,text_lengths,candidate_arguments,\
            candidate_argument_types,candidate_argument_arcs,candidate_argument_relateds, \
            candidate_triggers,candidate_trigger_arcs,candidate_trigger_relateds, \
            trigger_labels,trigger_argument_labels,argument_argument_labels,trigger_nums,argument_nums
