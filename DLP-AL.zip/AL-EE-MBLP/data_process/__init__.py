
from torch.utils.data import dataloader as module_dataloader

def makeDataSet(config):
    if 'legal' in config.config['train_set']['type'].lower():
        from data_process import legal_data_process as module_data_process
    elif 'military' in config.config['train_set']['type'].lower():
        from data_process import military_data_process as module_data_process
    else:
        from data_process import financial_data_process as module_data_process

    # setup data_set, data_process instances
    train_set = config.init_obj('train_set', module_data_process)
    valid_set = config.init_obj('valid_set', module_data_process)
    query_set = config.init_obj('query_set', module_data_process)


    return train_set, valid_set,query_set

def makeDataLoader(config):
    train_set = config.init_obj('train_set', module_data_process)
    valid_set = config.init_obj('valid_set', module_data_process)

    train_dataloader = module_dataloader.DataLoader(train_set, batch_size=train_set.batch_size,drop_last=True,
                                                    num_workers=train_set.num_workers, collate_fn=train_set.collate_fn)
    valid_dataloader = module_dataloader.DataLoader(valid_set, batch_size=valid_set.batch_size,
                                                    num_workers=valid_set.num_workers, collate_fn=valid_set.collate_fn)
    return train_dataloader, valid_dataloader