

from base import BaseDataSet
from pathlib import Path
from typing import List, Optional, Union, Dict
from dataclasses import dataclass
import torch
import json
import numpy as np
from tqdm import tqdm
from utils import get_trigger_candidate_index, get_candidate_argument, get_parse_arces, init_pyltp \
    , align_text_seg, get_arc_matrix, entity_map_id, get_candidate_arguments, get_trigger_gold, get_candidate_triggers, \
    get_arc_related, get_argument_argument_label

class FinancialSchema:
    def __init__(self):
        self.entity_type_2_id = {'O': 0, 'sub-org':1, 'sub-per':2, 'money':3, 'share-per':4, 'obj':5, 'target-company':6
                                    , 'obj-org':7, 'number':8, 'sub':9, 'title':10, 'obj-per':11, 'none':12,
                                 'date':13, 'share-org':14, 'proportion':15, 'collateral':16,'股份股权转让':17,'减持':18,
                                 '质押':19,'起诉':20,'投资':21
                                 }
        self.id_2_entity_type = {
            0: 'O', 1: 'sub-org', 2:'sub-per', 3:'money', 4:'share-per', 5:'obj', 6:'target-company', 7:'obj-org',
                                    8:'number', 9:'sub', 10:'title', 11:'obj-per', 12:'none', 13:'date', 14:'share-org',
                                    15:'proportion', 16:'collateral',17:'股份股权转让',18:'减持',19:'质押',20:'起诉',21:'投资',
        }

        self.event_type_2_id = {'O': 0, '股份股权转让': 1, '减持': 2, '质押': 3, '起诉': 4, '投资': 5, }
        self.id_2_event_type = {
            0: 'O', 1: '股份股权转让', 2: '减持', 3: '质押', 4: '起诉', 5: '投资'
        }

        self.role_type_2_id = {'O': 0, 'sub-org':1, 'sub-per':2, 'money':3, 'share-per':4, 'obj':5, 'target-company':6
                                    , 'obj-org':7, 'number':8, 'sub':9, 'title':10, 'obj-per':11, 'none':12,
                                 'date':13, 'share-org':14, 'proportion':15, 'collateral':16}

        self.id_2_role_type = {0: 'O', 1: 'sub-org', 2:'sub-per', 3:'money', 4:'share-per', 5:'obj', 6:'target-company', 7:'obj-org',
                                    8:'number', 9:'sub', 10:'title', 11:'obj-per', 12:'none', 13:'date', 14:'share-org',
                                    15:'proportion', 16:'collateral'}


        self.arc_type_id = {'O': 0, 'ATT': 1, 'ADV': 2, 'RAD': 3, 'WP': 4, 'SBV': 5, 'VOB': 6, 'HED': 7, 'COO': 8,
                            'CMP': 9,'POB': 10, 'LAD': 11, 'DBL': 12, 'FOB': 13, 'IOB': 14}

@dataclass
class InputExample:
    """
    A single training/test example for token classification.
    """

    guid: Optional[str]
    text: str
    entities: Dict
    relations: Dict
    events: Dict
    text_tokenized: List[str]
    postaggers: List[str]
    arces: List[str]

    def __post_init__(self):
        self.sent_len = len(self.text) + 2
        self.text_map_seg, self.seg_map_text = align_text_seg(self.text_tokenized)


@dataclass
class InputFeatures:
    """
    A single set of features of data.
    Property names are the same names as the corresponding inputs to a model.
    """
    guid: Optional[str]
    input_ids: List[int]
    attention_mask: List[int]
    entity_id_2_id: Dict

    candidate_arguments: List 
    candidate_argument_type: List  
    argument_arc: List 
    argument_arc_related: List  
    argument_max_num_arc: int  

    candidate_triggers: List 

    trigger_arc: List  
    trigger_arc_related: List  
    trigger_max_num_arc: int  

    trigger_label: List  
    triggers_arguments_label: List  
    argument_argument_label: List  



    def __post_init__(self):
        self.sent_len = len(self.input_ids)
        self.trigger_num = len(self.trigger_label)
        self.argument_num = len(self.triggers_arguments_label)



class FinancialDataset(BaseDataSet):
    def __init__(self, data_dir, ltp_dir, file_name, shuffle, transformer_model, overwrite_cache, force_download,
                 cache_dir, batch_size, num_workers):

        self.shuffle = shuffle
        self.data_dir = Path(data_dir)
        self.postagger, self.parser, self.seg = init_pyltp(ltp_dir=ltp_dir)
        self.file_name = file_name
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.schema = FinancialSchema()
        
        self.feature_cache_file = self.data_dir / '.cache' / '{}.cache'.format(file_name.split('.')[0])
        super(FinancialDataset, self).__init__(transformer_model=transformer_model, overwrite_cache=overwrite_cache,
                                           force_download=force_download, cache_dir=cache_dir)

    def read_examples_from_file(self):
        input_file = self.data_dir / self.file_name
        with input_file.open('r') as f:
            for line in tqdm(f):
                json_line = json.loads(line)
                text = json_line['text'][:510]
                
                text_tokenized = list(self.seg.segment(text))
               
                postaggers = self.postagger.postag(text_tokenized)
               
                arces = get_parse_arces(text_tokenized, self.postagger, self.parser)

                yield InputExample(guid=json_line['id'], text=text, entities=json_line['entities'],
                                   relations=json_line['relations'], events=json_line['events'],
                                   text_tokenized=text_tokenized, postaggers=postaggers, arces=arces)

    def convert_examples_to_features(self):
        features = []
        for example in self.read_examples_from_file():
            inputs = self.tokenizer.encode_plus(list(example.text), add_special_tokens=True, return_attention_mask=True)
            candidate_trigger_idxs = get_trigger_candidate_index(example.postaggers)
            gold_trigger_entities = get_trigger_gold(example.events)

            candidate_arguments_entities = get_candidate_argument(example.entities)
            arc_matrix = get_arc_matrix(example.sent_len, example.seg_map_text, example.arces, self.schema.arc_type_id)

            entity_id_2_id = entity_map_id(example.entities)

            candidate_arguments, candidate_argument_range, candidate_argument_type = \
                get_candidate_arguments(example.sent_len, self.schema.entity_type_2_id, candidate_arguments_entities)

            candidate_triggers, candidate_trigger_ranges, trigger_label, triggers_arguments_label = \
                get_candidate_triggers(example.sent_len, entity_id_2_id, self.schema, example.seg_map_text,
                                       candidate_trigger_idxs, gold_trigger_entities,
                                       example.events)

            trigger_arc, trigger_arc_related, trigger_max_num_arc = get_arc_related(example.sent_len,
                                                                                    example.text_map_seg,
                                                                                    example.seg_map_text,
                                                                                    candidate_triggers,
                                                                                    candidate_trigger_ranges,
                                                                                    arc_matrix)

            argument_arc, argument_arc_related, argument_max_num_arc = get_arc_related(example.sent_len,
                                                                                       example.text_map_seg,
                                                                                       example.seg_map_text,
                                                                                       candidate_arguments,
                                                                                       candidate_argument_range,
                                                                                       arc_matrix)

            argument_argument_label = get_argument_argument_label(example.relations, entity_id_2_id, self.schema)
            assert len(inputs.data['input_ids']) == example.sent_len, 'sent len is not equal'
            features.append(InputFeatures(guid=example.guid, input_ids=inputs.data['input_ids'],
                                          attention_mask=inputs.data['attention_mask'], entity_id_2_id=entity_id_2_id,
                                          candidate_arguments=candidate_arguments,
                                          candidate_argument_type=candidate_argument_type,
                                          argument_arc=argument_arc, argument_arc_related=argument_arc_related,
                                          argument_max_num_arc=argument_max_num_arc,
                                          candidate_triggers=candidate_triggers, trigger_arc=trigger_arc,
                                          trigger_arc_related=trigger_arc_related,
                                          trigger_max_num_arc=trigger_max_num_arc, trigger_label=trigger_label,
                                          triggers_arguments_label=triggers_arguments_label,
                                          argument_argument_label=argument_argument_label))
        return features

    def collate_fn(self, datas: List[InputFeatures]):

        max_seq_len = max([data.sent_len for data in datas])  
        K = max([len(data.candidate_triggers) for data in datas])  
        m = max([len(data.entity_id_2_id) for data in datas])  
        trigger_e = max([data.trigger_max_num_arc for data in datas])  
        argument_e = max([data.argument_max_num_arc for data in datas]) 

        input_ids = []
        attention_masks = []
        text_lengths = []

        candidate_arguments = []
        candidate_argument_types = []
        candidate_argument_arcs = []
        candidate_argument_relateds = []

        candidate_triggers = []
        candidate_trigger_arcs = []
        candidate_trigger_relateds = []

        trigger_labels = []
        trigger_argument_labels = []
        argument_argument_labels = []

        trigger_nums = []
        argument_nums = []

        for data in datas:
            text_lengths.append(data.sent_len)
            input_ids.append(data.input_ids + [self.tokenizer.pad_token_id] * (max_seq_len - data.sent_len))
            attention_masks.append((data.attention_mask + [0] * (max_seq_len - data.sent_len)))

            candidate_argument = np.zeros((m, max_seq_len))
            candidate_argument[:len(data.candidate_arguments), :data.sent_len] = np.array(data.candidate_arguments)
            candidate_arguments.append(candidate_argument)
            candidate_argument_types.append(
                data.candidate_argument_type + [0] * (m - len(data.candidate_argument_type)))

            argument_arcs_tensors = []
            argument_arc_related = []  
            for idx, arcs in enumerate(data.argument_arc):
                arcs_tensor = np.zeros(argument_e)
                arcs_tensor[:len(arcs)] = np.array(arcs)
                argument_arcs_tensors.append(arcs_tensor)  

                related_entities = np.zeros((argument_e, max_seq_len))  
                if len(arcs) > 0:
                    related_entities[:len(arcs), :data.sent_len] = np.array(data.argument_arc_related[idx])
                argument_arc_related.append(related_entities)

            candidate_argument_arc = np.zeros((m, argument_e))  
            candidate_argument_arc[:len(argument_arcs_tensors)] = np.array(argument_arcs_tensors)
            candidate_argument_arcs.append(candidate_argument_arc)

            candidate_argument_related = np.zeros((m, argument_e, max_seq_len))
            candidate_argument_related[:len(argument_arcs_tensors), :, :] = np.array(argument_arc_related)
            candidate_argument_relateds.append(candidate_argument_related)

            candidate_trigger = np.zeros((K, max_seq_len))
            candidate_trigger[:len(data.candidate_triggers), :data.sent_len] = np.array(data.candidate_triggers)
            candidate_triggers.append(candidate_trigger)

            arcs_tensors = []
            related = []
            for idx, arcs in enumerate(data.trigger_arc):
               
                arcs_tensor = np.zeros(data.trigger_max_num_arc)
                arcs_tensor[:len(arcs)] = np.array(arcs)
                arcs_tensors.append(arcs_tensor)

                related_entities = np.zeros((trigger_e, max_seq_len))
                if len(arcs) > 0:
                    related_entities[:len(arcs), :data.sent_len] = np.array(data.trigger_arc_related[idx])
                related.append(related_entities)

            candidate_trigger_arc = np.zeros((K, trigger_e))
            candidate_trigger_arc[:len(arcs_tensors), :data.trigger_max_num_arc] = np.array(arcs_tensors)
            candidate_trigger_arcs.append(candidate_trigger_arc)

            candidate_trigger_related = np.zeros((K, trigger_e, max_seq_len))
            candidate_trigger_related[:len(arcs_tensors), :, :max_seq_len] = np.array(related)
            candidate_trigger_relateds.append(candidate_trigger_related)

            # label
            # trigger_label [B,K]
            trigger_labels.append(data.trigger_label + [0] * (K - len(data.trigger_label)))

            # trigger_argument_label [B,K,M]
            trigger_argument_label = np.zeros((K, m))
            trigger_argument_label[:len(data.trigger_label), :(len(data.candidate_arguments))] =\
                np.array(data.triggers_arguments_label)
            trigger_argument_labels.append(trigger_argument_label)

            # argument_argument_label [B,M,M]
            argument_argument_label = np.zeros((m, m))
            argument_argument_label[:(len(data.entity_id_2_id)),
            :(len(data.entity_id_2_id))] = data.argument_argument_label
            argument_argument_labels.append(argument_argument_label)

            trigger_nums.append(data.trigger_num)
            argument_nums.append(data.argument_num)

        input_ids = torch.LongTensor(input_ids)
        attention_masks = torch.LongTensor(attention_masks)
        text_lengths = torch.LongTensor(text_lengths)

        candidate_arguments = torch.FloatTensor(candidate_arguments)
        candidate_argument_types = torch.LongTensor(candidate_argument_types)
        candidate_argument_arcs = torch.LongTensor(candidate_argument_arcs)
        candidate_argument_relateds = torch.FloatTensor(candidate_argument_relateds)

        candidate_triggers = torch.FloatTensor(candidate_triggers)
        candidate_trigger_arcs = torch.LongTensor(candidate_trigger_arcs)
        candidate_trigger_relateds = torch.FloatTensor(candidate_trigger_relateds)

        trigger_labels = torch.LongTensor(trigger_labels)
        trigger_argument_labels = torch.LongTensor(trigger_argument_labels)
        argument_argument_labels = torch.LongTensor(argument_argument_labels)

        return input_ids,attention_masks,text_lengths,candidate_arguments,\
            candidate_argument_types,candidate_argument_arcs,candidate_argument_relateds, \
            candidate_triggers,candidate_trigger_arcs,candidate_trigger_relateds, \
            trigger_labels,trigger_argument_labels,argument_argument_labels,trigger_nums,argument_nums
